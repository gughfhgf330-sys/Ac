import { useState } from "react"
import { createFileRoute } from "@tanstack/react-router"
import { Box, Globe2 } from "lucide-react"
import { AtlasView } from "@/components/atlas/atlas-view"
import { PhysicsView } from "@/components/physics/physics-view"

export const Route = createFileRoute("/")({ component: Home })

function Home() {
  const [mode, setMode] = useState<"atlas" | "lab">("atlas")
  return (
    <main className="flex h-dvh flex-col">
      <header className="flex shrink-0 items-center gap-3 border-b border-line px-3 py-2 md:px-5">
        <div className="grid size-11 shrink-0 place-items-center rounded-md bg-paper text-ink">
          <Globe2 className="size-5" aria-hidden="true" />
        </div>
        <div className="min-w-0">
          <p className="text-base font-semibold tracking-widest">ORBIS</p>
          <p className="truncate text-xs text-muted">اطلس جهان و آزمایشگاه فیزیک</p>
        </div>
        <div className="ms-auto flex rounded-full bg-panel p-1" role="tablist" aria-label="حالت">
          <button
            type="button"
            role="tab"
            aria-selected={mode === "atlas"}
            onClick={() => setMode("atlas")}
            className={
              "flex h-11 items-center gap-2 rounded-full px-4 text-sm font-medium " +
              (mode === "atlas" ? "bg-paper text-ink" : "text-muted")
            }
          >
            <Globe2 className="size-4" aria-hidden="true" />
            اطلس
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === "lab"}
            onClick={() => setMode("lab")}
            className={
              "flex h-11 items-center gap-2 rounded-full px-4 text-sm font-medium " +
              (mode === "lab" ? "bg-paper text-ink" : "text-muted")
            }
          >
            <Box className="size-4" aria-hidden="true" />
            فیزیک
          </button>
        </div>
      </header>
      <div className="min-h-0 flex-1">{mode === "atlas" ? <AtlasView /> : <PhysicsView />}</div>
    </main>
  )
}
