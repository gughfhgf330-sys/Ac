/** Keep in sync with the @theme tokens in src/styles.css. */
export const palette = {
  ink: "#101614",
  ink2: "#1a2420",
  panel: "#17211d",
  line: "#2c3b34",
  paper: "#f4f1e8",
  sand: "#e4d8c8",
  fg: "#f4f1e8",
  muted: "#9aab9f",
  accent: "#d4652f",
  sage: "#7d9a78",
  deep: "#1c3d32",
  scale0: "#f6efe4",
  scale1: "#e39a62",
  scale2: "#7a2e12",
  nodata: "#ddd6c8",
} as const
