import { geoEqualEarth, geoPath } from "d3-geo"
import { feature } from "topojson-client"
import type { Feature, FeatureCollection, Geometry } from "geojson"
import type { GeometryCollection, Topology } from "topojson-specification"
import world from "world-atlas/countries-110m.json"

export const MAP_W = 1000
export const MAP_H = 520

const HIDE = new Set(["010", "260"])

type AtlasProps = { name: string }

export type MapShape = {
  id: string
  name: string
  d: string
  cx: number
  cy: number
}

function shapeId(id: unknown, name: string) {
  if (id == null || id === "") return `name:${name}`
  const text = String(id)
  return /^\d+$/.test(text) ? text.padStart(3, "0") : text
}

export function buildShapes(): MapShape[] {
  const topo = world as unknown as Topology<{ countries: GeometryCollection<AtlasProps> }>
  const collection = feature(topo, topo.objects.countries) as FeatureCollection<
    Geometry,
    AtlasProps
  >
  const visible = {
    type: "FeatureCollection" as const,
    features: collection.features.filter((item) => !HIDE.has(shapeId(item.id, item.properties.name))),
  }
  const projection = geoEqualEarth().fitExtent(
    [
      [10, 10],
      [MAP_W - 10, MAP_H - 10],
    ],
    visible,
  )
  const path = geoPath(projection)
  const shapes: MapShape[] = []
  for (const item of visible.features as Feature<Geometry, AtlasProps>[]) {
    const name = item.properties?.name ?? "—"
    const d = path(item)
    if (!d) continue
    const [cx, cy] = path.centroid(item)
    shapes.push({
      id: shapeId(item.id, name),
      name,
      d,
      cx: Number.isFinite(cx) ? cx : MAP_W / 2,
      cy: Number.isFinite(cy) ? cy : MAP_H / 2,
    })
  }
  return shapes
}
