import { Component, useCallback, useEffect, useState, type ReactNode } from "react"
import { Canvas } from "@react-three/fiber"
import { Circle, Cylinder, Square, Trash2 } from "lucide-react"
import { palette } from "@/lib/palette"
import { formatInt } from "@/lib/metrics"
import { BODY_CAP, type BodyKind, type BodySpec } from "@/components/physics/types"

type SceneProps = {
  bodies: BodySpec[]
  gravity: number
  restitution: number
  onReady: () => void
}

let seq = 1

function createBody(kind: BodyKind, lift = 0): BodySpec {
  return {
    id: seq++,
    kind,
    size: 0.78 + Math.random() * 0.5,
    position: [(Math.random() - 0.5) * 3.4, 4.6 + lift + Math.random() * 1.6, (Math.random() - 0.5) * 3.4],
    rotation: [Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI],
  }
}

function starter() {
  const kinds: BodyKind[] = ["box", "sphere", "cylinder", "box", "sphere", "cylinder"]
  return kinds.map((kind, index) => createBody(kind, index * 0.7))
}

const SPAWN: { kind: BodyKind; label: string; icon: typeof Circle }[] = [
  { kind: "sphere", label: "کره", icon: Circle },
  { kind: "box", label: "جعبه", icon: Square },
  { kind: "cylinder", label: "استوانه", icon: Cylinder },
]

export function PhysicsView() {
  const [bodies, setBodies] = useState<BodySpec[]>(starter)
  const [gScale, setGScale] = useState(1)
  const [restitution, setRestitution] = useState(0.32)
  const [ready, setReady] = useState(false)
  const [Scene, setScene] = useState<((props: SceneProps) => ReactNode) | null>(null)
  const gravity = -9.81 * gScale
  const onReady = useCallback(() => setReady(true), [])

  useEffect(() => {
    let live = true
    void import("@/components/physics/physics-scene").then((mod) => {
      if (live) setScene(() => mod.PhysicsScene)
    })
    return () => {
      live = false
    }
  }, [])

  function spawn(kind: BodyKind) {
    setBodies((prev) => {
      const next = [...prev, createBody(kind)]
      return next.length > BODY_CAP ? next.slice(next.length - BODY_CAP) : next
    })
  }

  return (
    <div className="relative h-full bg-ink">
      <LabBoundary>
        {Scene ? (
          <Canvas
            shadows
            dpr={[1, 1.6]}
            camera={{ position: [7.2, 5.5, 9.2], fov: 40, near: 0.1, far: 80 }}
            className="h-full w-full touch-none"
          >
            <color attach="background" args={[palette.ink]} />
            <Scene bodies={bodies} gravity={gravity} restitution={restitution} onReady={onReady} />
          </Canvas>
        ) : null}
      </LabBoundary>
      {!ready ? (
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <p className="text-sm text-muted">در حال برپا کردن آزمایشگاه…</p>
        </div>
      ) : null}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 p-3">
        <div className="pointer-events-auto rounded-lg border border-line bg-ink/95 p-3">
          <div className="grid grid-cols-4 gap-2">
            {SPAWN.map((item) => (
              <button
                key={item.kind}
                type="button"
                onClick={() => spawn(item.kind)}
                className="flex h-11 items-center justify-center gap-1 rounded-md bg-paper text-sm font-medium text-ink"
              >
                <item.icon className="size-4 text-accent" />
                <span className="truncate">{item.label}</span>
              </button>
            ))}
            <button
              type="button"
              onClick={() => setBodies([])}
              className="flex h-11 items-center justify-center gap-1 rounded-md border border-line text-sm text-fg"
            >
              <Trash2 className="size-4" />
              <span className="truncate">پاک</span>
            </button>
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <label className="block text-sm">
              <span className="flex items-center justify-between">
                <span>گرانش</span>
                <span className="text-muted">{gLabel(gScale)}</span>
              </span>
              <input
                className="orb-range"
                type="range"
                min={0.15}
                max={2.8}
                step={0.05}
                value={gScale}
                aria-label="گرانش"
                onChange={(event) => setGScale(Number(event.target.value))}
              />
            </label>
            <label className="block text-sm">
              <span className="flex items-center justify-between">
                <span>ضریب بازگشت</span>
                <span className="text-muted">{formatInt(Math.round(restitution * 100))}٪</span>
              </span>
              <input
                className="orb-range"
                type="range"
                min={0}
                max={0.92}
                step={0.01}
                value={restitution}
                aria-label="ضریب بازگشت"
                onChange={(event) => setRestitution(Number(event.target.value))}
              />
            </label>
          </div>
          <p className="mt-1 flex items-center justify-between text-xs text-muted">
            <span>اجسام را بکشید. فضای خالی را برای چرخاندن صحنه بکشید.</span>
            <span>{formatInt(bodies.length)} جسم</span>
          </p>
        </div>
      </div>
    </div>
  )
}

function gLabel(scale: number) {
  return new Intl.NumberFormat("fa-IR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(scale) + " g"
}

class LabBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false }

  static getDerivedStateFromError() {
    return { failed: true }
  }

  componentDidCatch(error: unknown) {
    console.error(error)
  }

  render() {
    if (this.state.failed) {
      return (
        <div className="grid h-full place-items-center px-6 text-center">
          <p className="max-w-sm text-sm text-muted">آزمایشگاه بالا نیامد. یک‌بار صفحه را تازه کنید.</p>
        </div>
      )
    }
    return this.props.children
  }
}
