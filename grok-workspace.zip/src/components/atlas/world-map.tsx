import { memo, useCallback, useEffect, useMemo, useRef, useState, type MutableRefObject, type PointerEvent as ReactPointerEvent } from "react"
import { Minus, Plus, RotateCcw } from "lucide-react"
import { MAP_H, MAP_W, buildShapes, type MapShape } from "@/components/atlas/geography"

type Cam = { x: number; y: number; k: number }

const MIN_K = 1
const MAX_K = 12

export type MapTip = {
  title: string
  sub: string
  value: string
  extra: string
}

type Props = {
  fills: Record<string, string>
  hoverId: string | null
  selectedId: string | null
  tip: MapTip | null
  frameNonce: number
  frameId: string | null
  onHover: (id: string | null) => void
  onSelect: (id: string) => void
}

function clampCam(cam: Cam): Cam {
  const k = Math.min(MAX_K, Math.max(MIN_K, cam.k))
  return {
    k,
    x: Math.min(0, Math.max(MAP_W * (1 - k), cam.x)),
    y: Math.min(0, Math.max(MAP_H * (1 - k), cam.y)),
  }
}

function svgPoint(svg: SVGSVGElement, clientX: number, clientY: number) {
  const point = svg.createSVGPoint()
  point.x = clientX
  point.y = clientY
  const matrix = svg.getScreenCTM()
  if (!matrix) return { x: MAP_W / 2, y: MAP_H / 2 }
  const local = point.matrixTransform(matrix.inverse())
  return { x: local.x, y: local.y }
}

const Shapes = memo(function Shapes({
  shapes,
  fills,
  hoverId,
  selectedId,
  onHover,
  onSelect,
  armedClick,
}: {
  shapes: MapShape[]
  fills: Record<string, string>
  hoverId: string | null
  selectedId: string | null
  onHover: (id: string | null) => void
  onSelect: (id: string) => void
  armedClick: MutableRefObject<boolean>
}) {
  return shapes.map((shape) => {
    const cls =
      shape.id === selectedId ? "country is-selected" : shape.id === hoverId ? "country is-hover" : "country"
    return (
      <path
        key={shape.id}
        d={shape.d}
        className={cls}
        fill={fills[shape.id] ?? "var(--color-nodata)"}
        onMouseEnter={() => onHover(shape.id)}
        onMouseLeave={() => onHover(null)}
        onClick={(event) => {
          event.stopPropagation()
          if (!armedClick.current) return
          onSelect(shape.id)
        }}
      />
    )
  })
})

export function WorldMap({
  fills,
  hoverId,
  selectedId,
  tip,
  frameNonce,
  frameId,
  onHover,
  onSelect,
}: Props) {
  const shapes = useMemo(() => buildShapes(), [])
  const byId = useMemo(() => new Map(shapes.map((shape) => [shape.id, shape])), [shapes])
  const svgRef = useRef<SVGSVGElement>(null)
  const tipRef = useRef<HTMLDivElement>(null)
  const camRef = useRef<Cam>({ x: 0, y: 0, k: 1 })
  const animRef = useRef(0)
  const armedClick = useRef(true)
  const [cam, setCam] = useState<Cam>(camRef.current)
  const pointers = useRef(new Map<number, { x: number; y: number }>())
  const pinch = useRef<{ dist: number; wx: number; wy: number } | null>(null)
  const drag = useRef({ x: 0, y: 0, moved: false })
  const cursor = useRef({ x: 0, y: 0 })

  const commit = useCallback((next: Cam) => {
    const clamped = clampCam(next)
    camRef.current = clamped
    setCam(clamped)
  }, [])

  const stopAnim = useCallback(() => {
    cancelAnimationFrame(animRef.current)
  }, [])

  const animateTo = useCallback(
    (target: Cam) => {
      stopAnim()
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches
      const start = camRef.current
      const dest = clampCam(target)
      const t0 = performance.now()
      const dur = reduce ? 0 : 260
      const tick = (now: number) => {
        const u = dur === 0 ? 1 : Math.min(1, (now - t0) / dur)
        const eased = 1 - (1 - u) ** 3
        commit({
          x: start.x + (dest.x - start.x) * eased,
          y: start.y + (dest.y - start.y) * eased,
          k: start.k + (dest.k - start.k) * eased,
        })
        if (u < 1) animRef.current = requestAnimationFrame(tick)
      }
      animRef.current = requestAnimationFrame(tick)
    },
    [commit, stopAnim],
  )

  const zoomAt = useCallback(
    (clientX: number, clientY: number, factor: number, animate: boolean) => {
      const svg = svgRef.current
      if (!svg) return
      const current = camRef.current
      const { x: px, y: py } = svgPoint(svg, clientX, clientY)
      const wx = (px - current.x) / current.k
      const wy = (py - current.y) / current.k
      const k = Math.min(MAX_K, Math.max(MIN_K, current.k * factor))
      const next = { k, x: px - wx * k, y: py - wy * k }
      if (animate) animateTo(next)
      else {
        stopAnim()
        commit(next)
      }
    },
    [animateTo, commit, stopAnim],
  )

  const zoomCenter = useCallback(
    (factor: number) => {
      const svg = svgRef.current
      if (!svg) return
      const rect = svg.getBoundingClientRect()
      zoomAt(rect.left + rect.width / 2, rect.top + rect.height / 2, factor, true)
    },
    [zoomAt],
  )

  useEffect(() => {
    const svg = svgRef.current
    if (!svg) return
    const onWheel = (event: WheelEvent) => {
      event.preventDefault()
      const factor = Math.exp(-event.deltaY * 0.0015)
      zoomAt(event.clientX, event.clientY, factor, false)
    }
    svg.addEventListener("wheel", onWheel, { passive: false })
    return () => svg.removeEventListener("wheel", onWheel)
  }, [zoomAt])

  useEffect(() => {
    if (!frameNonce || !frameId) return
    const shape = byId.get(frameId)
    if (!shape) return
    const k = Math.min(MAX_K, Math.max(camRef.current.k, 3.6))
    animateTo({
      k,
      x: MAP_W / 2 - shape.cx * k,
      y: MAP_H / 2 - shape.cy * k,
    })
  }, [animateTo, byId, frameId, frameNonce])

  useEffect(() => () => cancelAnimationFrame(animRef.current), [])

  function placeTip(clientX: number, clientY: number) {
    const svg = svgRef.current
    const tipEl = tipRef.current
    if (!svg || !tipEl) return
    const rect = svg.getBoundingClientRect()
    const width = tipEl.offsetWidth
    const height = tipEl.offsetHeight
    let x = clientX - rect.left + 16
    let y = clientY - rect.top + 16
    if (x + width > rect.width - 8) x = clientX - rect.left - width - 16
    if (y + height > rect.height - 8) y = clientY - rect.top - height - 16
    tipEl.style.transform = `translate(${Math.max(8, x)}px, ${Math.max(8, y)}px)`
  }

  function onPointerDown(event: ReactPointerEvent<SVGSVGElement>) {
    if (event.button !== 0 && event.pointerType === "mouse") return
    const svg = svgRef.current
    if (!svg) return
    svg.setPointerCapture(event.pointerId)
    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY })
    if (pointers.current.size >= 2) {
      const [a, b] = [...pointers.current.values()]
      const midX = (a.x + b.x) / 2
      const midY = (a.y + b.y) / 2
      const { x: px, y: py } = svgPoint(svg, midX, midY)
      const current = camRef.current
      pinch.current = {
        dist: Math.max(12, Math.hypot(a.x - b.x, a.y - b.y)),
        wx: (px - current.x) / current.k,
        wy: (py - current.y) / current.k,
      }
      drag.current.moved = true
      armedClick.current = false
      stopAnim()
      return
    }
    drag.current = { x: event.clientX, y: event.clientY, moved: false }
    armedClick.current = true
  }

  function onPointerMove(event: ReactPointerEvent<SVGSVGElement>) {
    cursor.current = { x: event.clientX, y: event.clientY }
    if (tip) placeTip(event.clientX, event.clientY)
    if (!pointers.current.has(event.pointerId)) return
    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY })
    const svg = svgRef.current
    if (!svg) return
    if (pointers.current.size >= 2 && pinch.current) {
      const [a, b] = [...pointers.current.values()]
      const dist = Math.max(12, Math.hypot(a.x - b.x, a.y - b.y))
      const midX = (a.x + b.x) / 2
      const midY = (a.y + b.y) / 2
      const { x: px, y: py } = svgPoint(svg, midX, midY)
      const k = Math.min(MAX_K, Math.max(MIN_K, camRef.current.k * (dist / pinch.current.dist)))
      pinch.current.dist = dist
      stopAnim()
      commit({ k, x: px - pinch.current.wx * k, y: py - pinch.current.wy * k })
      return
    }
    const dx = event.clientX - drag.current.x
    const dy = event.clientY - drag.current.y
    if (!drag.current.moved && Math.hypot(dx, dy) < 5) return
    drag.current.moved = true
    armedClick.current = false
    const before = svgPoint(svg, drag.current.x, drag.current.y)
    const after = svgPoint(svg, event.clientX, event.clientY)
    drag.current.x = event.clientX
    drag.current.y = event.clientY
    stopAnim()
    commit({
      ...camRef.current,
      x: camRef.current.x + (after.x - before.x),
      y: camRef.current.y + (after.y - before.y),
    })
  }

  function onPointerUp(event: ReactPointerEvent<SVGSVGElement>) {
    pointers.current.delete(event.pointerId)
    if (pointers.current.size < 2) pinch.current = null
    if (drag.current.moved) armedClick.current = false
  }

  return (
    <div className="relative min-h-0 flex-1 overflow-hidden" dir="ltr">
      <svg
        ref={svgRef}
        viewBox={`0 0 ${MAP_W} ${MAP_H}`}
        className="h-full w-full touch-none bg-paper"
        role="application"
        aria-label="نقشهٔ رنگی جهان. برای جابه‌جایی بکشید و برای بزرگ‌نمایی اسکرول کنید."
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onDoubleClick={(event) => zoomAt(event.clientX, event.clientY, 1.7, true)}
        onKeyDown={(event) => {
          if (event.key === "+" || event.key === "=") zoomCenter(1.35)
          if (event.key === "-" || event.key === "_") zoomCenter(1 / 1.35)
          if (event.key === "0") animateTo({ x: 0, y: 0, k: 1 })
        }}
        tabIndex={0}
      >
        <g transform={`translate(${cam.x} ${cam.y}) scale(${cam.k})`}>
          <Shapes
            shapes={shapes}
            fills={fills}
            hoverId={hoverId}
            selectedId={selectedId}
            onHover={onHover}
            onSelect={onSelect}
            armedClick={armedClick}
          />
        </g>
      </svg>

      <div
        ref={tipRef}
        className={
          "pointer-events-none absolute top-0 left-0 z-20 max-w-56 rounded-md bg-ink px-3 py-2 text-fg shadow-md transition-opacity " +
          (tip ? "opacity-100" : "opacity-0")
        }
        dir="rtl"
      >
        {tip ? (
          <>
            <p className="text-sm font-semibold">{tip.title}</p>
            <p className="text-xs text-muted">{tip.sub}</p>
            <p className="mt-1 text-sm">{tip.value}</p>
            <p className="text-xs text-muted">{tip.extra}</p>
          </>
        ) : null}
      </div>

      <div className="absolute bottom-3 left-3 flex flex-col gap-2">
        <button
          type="button"
          className="grid size-11 place-items-center rounded-md border border-sand bg-paper text-ink"
          aria-label="بزرگ‌نمایی"
          onClick={() => zoomCenter(1.4)}
        >
          <Plus className="size-5" />
        </button>
        <button
          type="button"
          className="grid size-11 place-items-center rounded-md border border-sand bg-paper text-ink"
          aria-label="کوچک‌نمایی"
          onClick={() => zoomCenter(1 / 1.4)}
        >
          <Minus className="size-5" />
        </button>
        <button
          type="button"
          className="grid size-11 place-items-center rounded-md border border-sand bg-paper text-ink"
          aria-label="بازنشانی نما"
          onClick={() => animateTo({ x: 0, y: 0, k: 1 })}
        >
          <RotateCcw className="size-5" />
        </button>
      </div>
    </div>
  )
}
