import { useEffect, useMemo, useRef } from "react"
import { useFrame, useThree } from "@react-three/fiber"
import { Grid, OrbitControls } from "@react-three/drei"
import { CuboidCollider, Physics, RigidBody, BallCollider, CylinderCollider, useRapier, type RapierRigidBody } from "@react-three/rapier"
import * as THREE from "three"
import { palette } from "@/lib/palette"
import type { BodySpec } from "@/components/physics/types"

const KIND_COLOR = {
  sphere: palette.accent,
  box: palette.sage,
  cylinder: palette.sand,
} as const

type Props = {
  bodies: BodySpec[]
  gravity: number
  restitution: number
  onReady: () => void
}

export function PhysicsScene({ bodies, gravity, restitution, onReady }: Props) {
  return (
    <Physics
      gravity={[0, gravity, 0]}
      timeStep={1 / 60}
      numSolverIterations={8}
      numInternalPgsIterations={2}
    >
      <hemisphereLight args={[palette.paper, palette.ink2, 0.72]} />
      <ambientLight intensity={0.2} />
      <directionalLight
        position={[8, 14, 6]}
        intensity={2.5}
        color={palette.paper}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-camera-near={2}
        shadow-camera-far={36}
        shadow-camera-left={-12}
        shadow-camera-right={12}
        shadow-camera-top={12}
        shadow-camera-bottom={-12}
        shadow-bias={-0.0004}
      />
      <fog attach="fog" args={[palette.ink, 16, 32]} />
      <WakeAll gravity={gravity} restitution={restitution} />
      <Ready onReady={onReady} />
      <Tray restitution={restitution} />
      {bodies.map((body) => (
        <PlayBody key={body.id} spec={body} restitution={restitution} />
      ))}
      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        minDistance={4.5}
        maxDistance={20}
        minPolarAngle={0.18}
        maxPolarAngle={Math.PI / 2.04}
        target={[0, 0.7, 0]}
      />
    </Physics>
  )
}

function Ready({ onReady }: { onReady: () => void }) {
  useEffect(() => {
    onReady()
  }, [onReady])
  return null
}

function WakeAll({ gravity, restitution }: { gravity: number; restitution: number }) {
  const { world } = useRapier()
  useEffect(() => {
    world.forEachRigidBody((body) => body.wakeUp())
  }, [gravity, restitution, world])
  return null
}

function Tray({ restitution }: { restitution: number }) {
  return (
    <group>
      <RigidBody type="fixed" position={[0, -0.25, 0]} restitution={restitution} friction={0.95}>
        <mesh receiveShadow>
          <boxGeometry args={[16.4, 0.5, 16.4]} />
          <meshStandardMaterial color={palette.ink2} roughness={0.92} />
        </mesh>
      </RigidBody>
      <Grid
        position={[0, 0.02, 0]}
        args={[16, 16]}
        cellSize={1}
        cellThickness={0.6}
        cellColor={palette.line}
        sectionSize={4}
        sectionThickness={1.1}
        sectionColor={palette.deep}
        fadeDistance={22}
        fadeStrength={1.4}
        infiniteGrid={false}
      />
      <Wall position={[0, 0.7, -8.2]} args={[8.2, 0.7, 0.16]} restitution={restitution} />
      <Wall position={[0, 0.7, 8.2]} args={[8.2, 0.7, 0.16]} restitution={restitution} />
      <Wall position={[-8.2, 0.7, 0]} args={[0.16, 0.7, 8.2]} restitution={restitution} />
      <Wall position={[8.2, 0.7, 0]} args={[0.16, 0.7, 8.2]} restitution={restitution} />
    </group>
  )
}

function Wall({
  position,
  args,
  restitution,
}: {
  position: [number, number, number]
  args: [number, number, number]
  restitution: number
}) {
  return (
    <RigidBody type="fixed" position={position} restitution={restitution} friction={0.8} colliders={false}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[args[0] * 2, args[1] * 2, args[2] * 2]} />
        <meshStandardMaterial color={palette.panel} roughness={0.84} />
      </mesh>
      <CuboidCollider args={args} />
    </RigidBody>
  )
}

function PlayBody({ spec, restitution }: { spec: BodySpec; restitution: number }) {
  const ref = useRef<RapierRigidBody>(null)
  const dragging = useRef(false)
  const { camera, gl, raycaster } = useThree()
  const get = useThree((state) => state.get)
  const plane = useMemo(() => new THREE.Plane(), [])
  const hit = useMemo(() => new THREE.Vector3(), [])
  const normal = useMemo(() => new THREE.Vector3(), [])
  const anchor = useMemo(() => new THREE.Vector3(), [])
  const ndc = useMemo(() => new THREE.Vector2(), [])
  const target = useRef(new THREE.Vector3())
  const offset = useRef(new THREE.Vector3())

  useEffect(() => {
    const body = ref.current
    if (!body) return
    body.setLinvel(
      {
        x: (Math.random() - 0.5) * 0.7,
        y: 0,
        z: (Math.random() - 0.5) * 0.7,
      },
      true,
    )
    body.setAngvel(
      {
        x: (Math.random() - 0.5) * 2.4,
        y: (Math.random() - 0.5) * 2.4,
        z: (Math.random() - 0.5) * 2.4,
      },
      true,
    )
  }, [])

  useFrame(() => {
    const body = ref.current
    if (!body || !dragging.current) return
    const p = body.translation()
    const gain = 22
    const max = 16
    const vx = Math.max(-max, Math.min(max, (target.current.x - p.x) * gain))
    const vy = Math.max(-max, Math.min(max, (target.current.y - p.y) * gain))
    const vz = Math.max(-max, Math.min(max, (target.current.z - p.z) * gain))
    body.setLinvel({ x: vx, y: vy, z: vz }, true)
  })

  function aim(ev: { clientX: number; clientY: number }) {
    const rect = gl.domElement.getBoundingClientRect()
    const x = ((ev.clientX - rect.left) / rect.width) * 2 - 1
    const y = -((ev.clientY - rect.top) / rect.height) * 2 + 1
    raycaster.setFromCamera(ndc.set(x, y), camera)
    if (!raycaster.ray.intersectPlane(plane, hit)) return
    target.current.set(
      hit.x + offset.current.x,
      Math.max(0.45, hit.y + offset.current.y),
      hit.z + offset.current.z,
    )
  }

  return (
    <RigidBody
      ref={ref}
      position={spec.position}
      rotation={spec.rotation}
      restitution={restitution}
      friction={0.72}
      colliders={false}
      linearDamping={0.12}
      angularDamping={0.18}
      ccd
      canSleep
    >
      <mesh
        castShadow
        receiveShadow
        onPointerDown={(event) => {
          event.stopPropagation()
          const controls = get().controls as { enabled: boolean } | null
          if (controls) controls.enabled = false
          const body = ref.current
          if (!body) return
          dragging.current = true
          gl.domElement.style.cursor = "grabbing"
          const p = body.translation()
          camera.getWorldDirection(normal)
          anchor.set(p.x, p.y, p.z)
          plane.setFromNormalAndCoplanarPoint(normal, anchor)
          const rect = gl.domElement.getBoundingClientRect()
          const x = ((event.nativeEvent.clientX - rect.left) / rect.width) * 2 - 1
          const y = -((event.nativeEvent.clientY - rect.top) / rect.height) * 2 + 1
          raycaster.setFromCamera(ndc.set(x, y), camera)
          if (raycaster.ray.intersectPlane(plane, hit)) offset.current.set(p.x - hit.x, p.y - hit.y, p.z - hit.z)
          else offset.current.set(0, 0, 0)
          target.current.set(p.x, p.y, p.z)
          const move = (ev: PointerEvent) => aim(ev)
          const up = () => {
            dragging.current = false
            gl.domElement.style.cursor = "grab"
            if (controls) controls.enabled = true
            window.removeEventListener("pointermove", move)
            window.removeEventListener("pointerup", up)
            window.removeEventListener("pointercancel", up)
          }
          window.addEventListener("pointermove", move)
          window.addEventListener("pointerup", up)
          window.addEventListener("pointercancel", up)
        }}
        onPointerOver={(event) => {
          event.stopPropagation()
          if (!dragging.current) gl.domElement.style.cursor = "grab"
        }}
        onPointerOut={() => {
          if (!dragging.current) gl.domElement.style.cursor = ""
        }}
      >
        <BodyMesh kind={spec.kind} size={spec.size} />
      </mesh>
      <BodyCollider kind={spec.kind} size={spec.size} />
    </RigidBody>
  )
}

function BodyMesh({ kind, size }: { kind: BodySpec["kind"]; size: number }) {
  const color = KIND_COLOR[kind]
  if (kind === "sphere") {
    return (
      <>
        <sphereGeometry args={[size * 0.46, 28, 20]} />
        <meshStandardMaterial color={color} roughness={0.36} metalness={0.08} />
      </>
    )
  }
  if (kind === "box") {
    const edge = size * 0.8
    return (
      <>
        <boxGeometry args={[edge, edge, edge]} />
        <meshStandardMaterial color={color} roughness={0.48} metalness={0.05} />
      </>
    )
  }
  return (
    <>
      <cylinderGeometry args={[size * 0.36, size * 0.36, size * 0.96, 24]} />
      <meshStandardMaterial color={color} roughness={0.42} metalness={0.1} />
    </>
  )
}

function BodyCollider({ kind, size }: { kind: BodySpec["kind"]; size: number }) {
  if (kind === "sphere") return <BallCollider args={[size * 0.46]} />
  if (kind === "box") {
    const half = size * 0.4
    return <CuboidCollider args={[half, half, half]} />
  }
  return <CylinderCollider args={[size * 0.48, size * 0.36]} />
}
