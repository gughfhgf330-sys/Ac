export type Stat = { v: number; y: number }

export type CountryDatum = {
  id: string
  iso3: string | null
  name: string
  nameFa: string
  regionFa: string
  incomeFa: string | null
  population: Stat | null
  gdpPpp: Stat | null
  life: Stat | null
  internet: Stat | null
  co2: Stat | null
}

export const COUNTRIES: Record<string, CountryDatum> = {
  "242": {
    "id": "242",
    "iso3": "FJI",
    "name": "Fiji",
    "nameFa": "فیجی",
    "regionFa": "ملانزی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 933154,
      "y": 2025
    },
    "gdpPpp": {
      "v": 16337.5723,
      "y": 2025
    },
    "life": {
      "v": 67.463,
      "y": 2024
    },
    "internet": {
      "v": 74.7052,
      "y": 2024
    },
    "co2": {
      "v": 1.6222,
      "y": 2024
    }
  },
  "834": {
    "id": "834",
    "iso3": "TZA",
    "name": "Tanzania",
    "nameFa": "تانزانیا",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 70545865,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4470.9541,
      "y": 2025
    },
    "life": {
      "v": 67.212,
      "y": 2024
    },
    "internet": {
      "v": 31.1621,
      "y": 2024
    },
    "co2": {
      "v": 0.3112,
      "y": 2024
    }
  },
  "732": {
    "id": "732",
    "iso3": "ESH",
    "name": "W. Sahara",
    "nameFa": "صحرای غربی",
    "regionFa": "شمال آفریقا",
    "incomeFa": null,
    "population": null,
    "gdpPpp": null,
    "life": null,
    "internet": null,
    "co2": null
  },
  "124": {
    "id": "124",
    "iso3": "CAN",
    "name": "Canada",
    "nameFa": "کانادا",
    "regionFa": "آمریکای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 41651653,
      "y": 2025
    },
    "gdpPpp": {
      "v": 66745.8249,
      "y": 2025
    },
    "life": {
      "v": 82.108,
      "y": 2024
    },
    "internet": {
      "v": 94.3533,
      "y": 2024
    },
    "co2": {
      "v": 14.0073,
      "y": 2024
    }
  },
  "840": {
    "id": "840",
    "iso3": "USA",
    "name": "United States of America",
    "nameFa": "ایالات متحده",
    "regionFa": "آمریکای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 341784857,
      "y": 2025
    },
    "gdpPpp": {
      "v": 90026.5163,
      "y": 2025
    },
    "life": {
      "v": 78.8902,
      "y": 2024
    },
    "internet": {
      "v": 94.6938,
      "y": 2024
    },
    "co2": {
      "v": 13.6239,
      "y": 2024
    }
  },
  "398": {
    "id": "398",
    "iso3": "KAZ",
    "name": "Kazakhstan",
    "nameFa": "قزاقستان",
    "regionFa": "آسیای مرکزی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 20843754,
      "y": 2025
    },
    "gdpPpp": {
      "v": 44293.484,
      "y": 2025
    },
    "life": {
      "v": 74.531,
      "y": 2024
    },
    "internet": {
      "v": 93.3917,
      "y": 2024
    },
    "co2": {
      "v": 12.5678,
      "y": 2024
    }
  },
  "860": {
    "id": "860",
    "iso3": "UZB",
    "name": "Uzbekistan",
    "nameFa": "ازبکستان",
    "regionFa": "آسیای مرکزی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 37053428,
      "y": 2025
    },
    "gdpPpp": {
      "v": 13601.2917,
      "y": 2025
    },
    "life": {
      "v": 72.528,
      "y": 2024
    },
    "internet": {
      "v": 89.5055,
      "y": 2024
    },
    "co2": {
      "v": 4.085,
      "y": 2024
    }
  },
  "598": {
    "id": "598",
    "iso3": "PNG",
    "name": "Papua New Guinea",
    "nameFa": "پاپوآ گینه نو",
    "regionFa": "ملانزی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 10762817,
      "y": 2025
    },
    "gdpPpp": {
      "v": 5214.7683,
      "y": 2025
    },
    "life": {
      "v": 66.256,
      "y": 2024
    },
    "internet": {
      "v": 18.8116,
      "y": 2024
    },
    "co2": {
      "v": 0.517,
      "y": 2024
    }
  },
  "360": {
    "id": "360",
    "iso3": "IDN",
    "name": "Indonesia",
    "nameFa": "اندونزی",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 285721236,
      "y": 2025
    },
    "gdpPpp": {
      "v": 17659.7921,
      "y": 2025
    },
    "life": {
      "v": 71.288,
      "y": 2024
    },
    "internet": {
      "v": 72.7808,
      "y": 2024
    },
    "co2": {
      "v": 2.865,
      "y": 2024
    }
  },
  "032": {
    "id": "032",
    "iso3": "ARG",
    "name": "Argentina",
    "nameFa": "آرژانتین",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 45851378,
      "y": 2025
    },
    "gdpPpp": {
      "v": 32586.6312,
      "y": 2025
    },
    "life": {
      "v": 77.543,
      "y": 2024
    },
    "internet": {
      "v": 89.6672,
      "y": 2024
    },
    "co2": {
      "v": 4.0107,
      "y": 2024
    }
  },
  "152": {
    "id": "152",
    "iso3": "CHL",
    "name": "Chile",
    "nameFa": "شیلی",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 19859921,
      "y": 2025
    },
    "gdpPpp": {
      "v": 37774.0879,
      "y": 2025
    },
    "life": {
      "v": 81.359,
      "y": 2024
    },
    "internet": {
      "v": 95.5902,
      "y": 2024
    },
    "co2": {
      "v": 3.9374,
      "y": 2024
    }
  },
  "180": {
    "id": "180",
    "iso3": "COD",
    "name": "Dem. Rep. Congo",
    "nameFa": "جمهوری دموکراتیک کنگو",
    "regionFa": "مرکز آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 112832473,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1919.8225,
      "y": 2025
    },
    "life": {
      "v": 62.074,
      "y": 2024
    },
    "internet": {
      "v": 19.6735,
      "y": 2024
    },
    "co2": {
      "v": 0.0568,
      "y": 2024
    }
  },
  "706": {
    "id": "706",
    "iso3": "SOM",
    "name": "Somalia",
    "nameFa": "سومالی",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 19654739,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1642.7703,
      "y": 2025
    },
    "life": {
      "v": 58.967,
      "y": 2024
    },
    "internet": {
      "v": 27.9402,
      "y": 2024
    },
    "co2": {
      "v": 0.0455,
      "y": 2024
    }
  },
  "404": {
    "id": "404",
    "iso3": "KEN",
    "name": "Kenya",
    "nameFa": "کنیا",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 57532493,
      "y": 2025
    },
    "gdpPpp": {
      "v": 7015.9358,
      "y": 2025
    },
    "life": {
      "v": 63.834,
      "y": 2024
    },
    "internet": {
      "v": 34.9762,
      "y": 2024
    },
    "co2": {
      "v": 0.3834,
      "y": 2024
    }
  },
  "729": {
    "id": "729",
    "iso3": "SDN",
    "name": "Sudan",
    "nameFa": "سودان",
    "regionFa": "شمال آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 51662147,
      "y": 2025
    },
    "gdpPpp": {
      "v": 2192.2722,
      "y": 2025
    },
    "life": {
      "v": 66.521,
      "y": 2024
    },
    "internet": {
      "v": 18.6,
      "y": 2017
    },
    "co2": {
      "v": 0.4335,
      "y": 2024
    }
  },
  "148": {
    "id": "148",
    "iso3": "TCD",
    "name": "Chad",
    "nameFa": "چاد",
    "regionFa": "مرکز آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 21003705,
      "y": 2025
    },
    "gdpPpp": {
      "v": 2902.7406,
      "y": 2025
    },
    "life": {
      "v": 55.238,
      "y": 2024
    },
    "internet": {
      "v": 12.6269,
      "y": 2024
    },
    "co2": {
      "v": 0.1425,
      "y": 2024
    }
  },
  "332": {
    "id": "332",
    "iso3": "HTI",
    "name": "Haiti",
    "nameFa": "هائیتی",
    "regionFa": "کارائیب",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 11906095,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3133.7235,
      "y": 2025
    },
    "life": {
      "v": 65.119,
      "y": 2024
    },
    "internet": {
      "v": 47.8614,
      "y": 2024
    },
    "co2": {
      "v": 0.2985,
      "y": 2024
    }
  },
  "214": {
    "id": "214",
    "iso3": "DOM",
    "name": "Dominican Rep.",
    "nameFa": "جمهوری دومینیکن",
    "regionFa": "کارائیب",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 11520487,
      "y": 2025
    },
    "gdpPpp": {
      "v": 28721.0965,
      "y": 2025
    },
    "life": {
      "v": 73.868,
      "y": 2024
    },
    "internet": {
      "v": 91.0022,
      "y": 2024
    },
    "co2": {
      "v": 2.9947,
      "y": 2024
    }
  },
  "643": {
    "id": "643",
    "iso3": "RUS",
    "name": "Russia",
    "nameFa": "روسیه",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 143513328,
      "y": 2025
    },
    "gdpPpp": {
      "v": 49568.1406,
      "y": 2025
    },
    "life": {
      "v": 73.4405,
      "y": 2024
    },
    "internet": {
      "v": 94.365,
      "y": 2024
    },
    "co2": {
      "v": 13.9845,
      "y": 2024
    }
  },
  "044": {
    "id": "044",
    "iso3": "BHS",
    "name": "Bahamas",
    "nameFa": "باهاما",
    "regionFa": "کارائیب",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 403033,
      "y": 2025
    },
    "gdpPpp": {
      "v": 41257.7651,
      "y": 2024
    },
    "life": {
      "v": 74.71,
      "y": 2024
    },
    "internet": {
      "v": 92.4727,
      "y": 2024
    },
    "co2": {
      "v": 3.6363,
      "y": 2024
    }
  },
  "238": {
    "id": "238",
    "iso3": "FLK",
    "name": "Falkland Is.",
    "nameFa": "جزایر فالکلند",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": null,
    "population": null,
    "gdpPpp": null,
    "life": null,
    "internet": null,
    "co2": null
  },
  "578": {
    "id": "578",
    "iso3": "NOR",
    "name": "Norway",
    "nameFa": "نروژ",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 5610870,
      "y": 2025
    },
    "gdpPpp": {
      "v": 104043.6664,
      "y": 2025
    },
    "life": {
      "v": 83.161,
      "y": 2024
    },
    "internet": {
      "v": 99.0,
      "y": 2024
    },
    "co2": {
      "v": 7.1783,
      "y": 2024
    }
  },
  "304": {
    "id": "304",
    "iso3": "GRL",
    "name": "Greenland",
    "nameFa": "گرینلند",
    "regionFa": "آمریکای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 56831,
      "y": 2025
    },
    "gdpPpp": {
      "v": 78905.5801,
      "y": 2023
    },
    "life": {
      "v": 70.2734,
      "y": 2024
    },
    "internet": {
      "v": 69.4825,
      "y": 2017
    },
    "co2": {
      "v": 10.4529,
      "y": 2024
    }
  },
  "260": {
    "id": "260",
    "iso3": "ATF",
    "name": "Fr. S. Antarctic Lands",
    "nameFa": "سرزمین‌های جنوبی فرانسه",
    "regionFa": "شرق آفریقا",
    "incomeFa": null,
    "population": null,
    "gdpPpp": null,
    "life": null,
    "internet": null,
    "co2": null
  },
  "626": {
    "id": "626",
    "iso3": "TLS",
    "name": "Timor-Leste",
    "nameFa": "تیمور شرقی",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 1418517,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4809.4902,
      "y": 2025
    },
    "life": {
      "v": 67.904,
      "y": 2024
    },
    "internet": {
      "v": 35.042,
      "y": 2021
    },
    "co2": {
      "v": 0.4993,
      "y": 2024
    }
  },
  "710": {
    "id": "710",
    "iso3": "ZAF",
    "name": "South Africa",
    "nameFa": "آفریقای جنوبی",
    "regionFa": "جنوب آفریقا",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 64747319,
      "y": 2025
    },
    "gdpPpp": {
      "v": 15905.6794,
      "y": 2025
    },
    "life": {
      "v": 66.312,
      "y": 2024
    },
    "internet": {
      "v": 78.3576,
      "y": 2024
    },
    "co2": {
      "v": 6.8768,
      "y": 2024
    }
  },
  "426": {
    "id": "426",
    "iso3": "LSO",
    "name": "Lesotho",
    "nameFa": "لسوتو",
    "regionFa": "جنوب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 2363325,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3184.1173,
      "y": 2025
    },
    "life": {
      "v": 57.798,
      "y": 2024
    },
    "internet": {
      "v": 51.7966,
      "y": 2024
    },
    "co2": {
      "v": 0.4281,
      "y": 2024
    }
  },
  "484": {
    "id": "484",
    "iso3": "MEX",
    "name": "Mexico",
    "nameFa": "مکزیک",
    "regionFa": "آمریکای مرکزی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 131946900,
      "y": 2025
    },
    "gdpPpp": {
      "v": 25868.4788,
      "y": 2025
    },
    "life": {
      "v": 75.264,
      "y": 2024
    },
    "internet": {
      "v": 83.1223,
      "y": 2024
    },
    "co2": {
      "v": 3.6374,
      "y": 2024
    }
  },
  "858": {
    "id": "858",
    "iso3": "URY",
    "name": "Uruguay",
    "nameFa": "اروگوئه",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 3384688,
      "y": 2025
    },
    "gdpPpp": {
      "v": 38314.8861,
      "y": 2025
    },
    "life": {
      "v": 78.287,
      "y": 2024
    },
    "internet": {
      "v": 91.9911,
      "y": 2024
    },
    "co2": {
      "v": 2.5676,
      "y": 2024
    }
  },
  "076": {
    "id": "076",
    "iso3": "BRA",
    "name": "Brazil",
    "nameFa": "برزیل",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 212812405,
      "y": 2025
    },
    "gdpPpp": {
      "v": 23433.2898,
      "y": 2025
    },
    "life": {
      "v": 76.023,
      "y": 2024
    },
    "internet": {
      "v": 84.4635,
      "y": 2024
    },
    "co2": {
      "v": 2.3183,
      "y": 2024
    }
  },
  "068": {
    "id": "068",
    "iso3": "BOL",
    "name": "Bolivia",
    "nameFa": "بولیوی",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 12581843,
      "y": 2025
    },
    "gdpPpp": {
      "v": 12873.0395,
      "y": 2025
    },
    "life": {
      "v": 68.739,
      "y": 2024
    },
    "internet": {
      "v": 79.7047,
      "y": 2024
    },
    "co2": {
      "v": 2.2907,
      "y": 2024
    }
  },
  "604": {
    "id": "604",
    "iso3": "PER",
    "name": "Peru",
    "nameFa": "پرو",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 34576665,
      "y": 2025
    },
    "gdpPpp": {
      "v": 18816.1046,
      "y": 2025
    },
    "life": {
      "v": 77.941,
      "y": 2024
    },
    "internet": {
      "v": 81.9571,
      "y": 2024
    },
    "co2": {
      "v": 2.0242,
      "y": 2024
    }
  },
  "170": {
    "id": "170",
    "iso3": "COL",
    "name": "Colombia",
    "nameFa": "کلمبیا",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 53425635,
      "y": 2025
    },
    "gdpPpp": {
      "v": 22640.4225,
      "y": 2025
    },
    "life": {
      "v": 77.913,
      "y": 2024
    },
    "internet": {
      "v": 79.3454,
      "y": 2024
    },
    "co2": {
      "v": 1.7978,
      "y": 2024
    }
  },
  "591": {
    "id": "591",
    "iso3": "PAN",
    "name": "Panama",
    "nameFa": "پاناما",
    "regionFa": "آمریکای مرکزی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 4571189,
      "y": 2025
    },
    "gdpPpp": {
      "v": 43902.1632,
      "y": 2025
    },
    "life": {
      "v": 79.775,
      "y": 2024
    },
    "internet": {
      "v": 72.7715,
      "y": 2024
    },
    "co2": {
      "v": 2.7383,
      "y": 2024
    }
  },
  "188": {
    "id": "188",
    "iso3": "CRI",
    "name": "Costa Rica",
    "nameFa": "کاستاریکا",
    "regionFa": "آمریکای مرکزی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 5152950,
      "y": 2025
    },
    "gdpPpp": {
      "v": 33814.7696,
      "y": 2025
    },
    "life": {
      "v": 80.996,
      "y": 2024
    },
    "internet": {
      "v": 87.1702,
      "y": 2024
    },
    "co2": {
      "v": 1.6328,
      "y": 2024
    }
  },
  "558": {
    "id": "558",
    "iso3": "NIC",
    "name": "Nicaragua",
    "nameFa": "نیکاراگوئه",
    "regionFa": "آمریکای مرکزی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 7007502,
      "y": 2025
    },
    "gdpPpp": {
      "v": 9283.923,
      "y": 2025
    },
    "life": {
      "v": 75.1,
      "y": 2024
    },
    "internet": {
      "v": 61.3955,
      "y": 2024
    },
    "co2": {
      "v": 0.8298,
      "y": 2024
    }
  },
  "340": {
    "id": "340",
    "iso3": "HND",
    "name": "Honduras",
    "nameFa": "هندوراس",
    "regionFa": "آمریکای مرکزی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 11005850,
      "y": 2025
    },
    "gdpPpp": {
      "v": 7871.0913,
      "y": 2025
    },
    "life": {
      "v": 73.044,
      "y": 2024
    },
    "internet": {
      "v": 58.6227,
      "y": 2024
    },
    "co2": {
      "v": 1.1355,
      "y": 2024
    }
  },
  "222": {
    "id": "222",
    "iso3": "SLV",
    "name": "El Salvador",
    "nameFa": "السالوادور",
    "regionFa": "آمریکای مرکزی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 6365503,
      "y": 2025
    },
    "gdpPpp": {
      "v": 14101.1775,
      "y": 2025
    },
    "life": {
      "v": 72.302,
      "y": 2024
    },
    "internet": {
      "v": 66.4777,
      "y": 2024
    },
    "co2": {
      "v": 1.5057,
      "y": 2024
    }
  },
  "320": {
    "id": "320",
    "iso3": "GTM",
    "name": "Guatemala",
    "nameFa": "گواتمالا",
    "regionFa": "آمریکای مرکزی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 18687881,
      "y": 2025
    },
    "gdpPpp": {
      "v": 15197.0831,
      "y": 2025
    },
    "life": {
      "v": 72.746,
      "y": 2024
    },
    "internet": {
      "v": 60.2214,
      "y": 2024
    },
    "co2": {
      "v": 1.1067,
      "y": 2024
    }
  },
  "084": {
    "id": "084",
    "iso3": "BLZ",
    "name": "Belize",
    "nameFa": "بلیز",
    "regionFa": "آمریکای مرکزی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 422924,
      "y": 2025
    },
    "gdpPpp": {
      "v": 14965.7521,
      "y": 2025
    },
    "life": {
      "v": 73.739,
      "y": 2024
    },
    "internet": {
      "v": 80.0058,
      "y": 2024
    },
    "co2": {
      "v": 0.9325,
      "y": 2024
    }
  },
  "862": {
    "id": "862",
    "iso3": "VEN",
    "name": "Venezuela",
    "nameFa": "ونزوئلا",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 28516896,
      "y": 2025
    },
    "gdpPpp": {
      "v": 21282.64,
      "y": 2011
    },
    "life": {
      "v": 72.673,
      "y": 2024
    },
    "internet": {
      "v": 76.6789,
      "y": 2024
    },
    "co2": {
      "v": 3.3941,
      "y": 2024
    }
  },
  "328": {
    "id": "328",
    "iso3": "GUY",
    "name": "Guyana",
    "nameFa": "گویان",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 835986,
      "y": 2025
    },
    "gdpPpp": {
      "v": 97899.0116,
      "y": 2025
    },
    "life": {
      "v": 70.319,
      "y": 2024
    },
    "internet": {
      "v": 83.0008,
      "y": 2024
    },
    "co2": {
      "v": 4.5586,
      "y": 2024
    }
  },
  "740": {
    "id": "740",
    "iso3": "SUR",
    "name": "Suriname",
    "nameFa": "سورینام",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 639850,
      "y": 2025
    },
    "gdpPpp": {
      "v": 22652.3953,
      "y": 2025
    },
    "life": {
      "v": 73.757,
      "y": 2024
    },
    "internet": {
      "v": 87.4,
      "y": 2023
    },
    "co2": {
      "v": 4.0611,
      "y": 2024
    }
  },
  "250": {
    "id": "250",
    "iso3": "FRA",
    "name": "France",
    "nameFa": "فرانسه",
    "regionFa": "اروپای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 68720337,
      "y": 2025
    },
    "gdpPpp": {
      "v": 63975.3536,
      "y": 2025
    },
    "life": {
      "v": 82.9805,
      "y": 2024
    },
    "internet": {
      "v": 88.6538,
      "y": 2024
    },
    "co2": {
      "v": 4.0036,
      "y": 2024
    }
  },
  "218": {
    "id": "218",
    "iso3": "ECU",
    "name": "Ecuador",
    "nameFa": "اکوادور",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 18289896,
      "y": 2025
    },
    "gdpPpp": {
      "v": 16756.654,
      "y": 2025
    },
    "life": {
      "v": 77.579,
      "y": 2024
    },
    "internet": {
      "v": 77.1727,
      "y": 2024
    },
    "co2": {
      "v": 2.6447,
      "y": 2024
    }
  },
  "630": {
    "id": "630",
    "iso3": "PRI",
    "name": "Puerto Rico",
    "nameFa": "پورتوریکو",
    "regionFa": "کارائیب",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 3184835,
      "y": 2025
    },
    "gdpPpp": {
      "v": 52195.5534,
      "y": 2025
    },
    "life": {
      "v": 81.902,
      "y": 2024
    },
    "internet": {
      "v": 87.2918,
      "y": 2022
    },
    "co2": {
      "v": 4.8181,
      "y": 2024
    }
  },
  "388": {
    "id": "388",
    "iso3": "JAM",
    "name": "Jamaica",
    "nameFa": "جامائیکا",
    "regionFa": "کارائیب",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 2837077,
      "y": 2025
    },
    "gdpPpp": {
      "v": 13291.2538,
      "y": 2025
    },
    "life": {
      "v": 71.606,
      "y": 2024
    },
    "internet": {
      "v": 90.1087,
      "y": 2024
    },
    "co2": {
      "v": 2.8438,
      "y": 2024
    }
  },
  "192": {
    "id": "192",
    "iso3": "CUB",
    "name": "Cuba",
    "nameFa": "کوبا",
    "regionFa": "کارائیب",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 10937203,
      "y": 2025
    },
    "gdpPpp": null,
    "life": {
      "v": 78.264,
      "y": 2024
    },
    "internet": {
      "v": 70.477,
      "y": 2024
    },
    "co2": {
      "v": 1.913,
      "y": 2024
    }
  },
  "716": {
    "id": "716",
    "iso3": "ZWE",
    "name": "Zimbabwe",
    "nameFa": "زیمبابوه",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 16950795,
      "y": 2025
    },
    "gdpPpp": {
      "v": 6470.4161,
      "y": 2025
    },
    "life": {
      "v": 63.064,
      "y": 2024
    },
    "internet": {
      "v": 41.6428,
      "y": 2024
    },
    "co2": {
      "v": 0.7728,
      "y": 2024
    }
  },
  "072": {
    "id": "072",
    "iso3": "BWA",
    "name": "Botswana",
    "nameFa": "بوتسوانا",
    "regionFa": "جنوب آفریقا",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 2562122,
      "y": 2025
    },
    "gdpPpp": {
      "v": 20697.9105,
      "y": 2025
    },
    "life": {
      "v": 69.293,
      "y": 2024
    },
    "internet": {
      "v": 57.4595,
      "y": 2024
    },
    "co2": {
      "v": 2.7375,
      "y": 2024
    }
  },
  "516": {
    "id": "516",
    "iso3": "NAM",
    "name": "Namibia",
    "nameFa": "نامیبیا",
    "regionFa": "جنوب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 3092816,
      "y": 2025
    },
    "gdpPpp": {
      "v": 11985.72,
      "y": 2025
    },
    "life": {
      "v": 67.516,
      "y": 2024
    },
    "internet": {
      "v": 64.8746,
      "y": 2024
    },
    "co2": {
      "v": 1.2045,
      "y": 2024
    }
  },
  "686": {
    "id": "686",
    "iso3": "SEN",
    "name": "Senegal",
    "nameFa": "سنگال",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 18931966,
      "y": 2025
    },
    "gdpPpp": {
      "v": 5463.2183,
      "y": 2025
    },
    "life": {
      "v": 68.924,
      "y": 2024
    },
    "internet": {
      "v": 60.1178,
      "y": 2024
    },
    "co2": {
      "v": 0.7676,
      "y": 2024
    }
  },
  "466": {
    "id": "466",
    "iso3": "MLI",
    "name": "Mali",
    "nameFa": "مالی",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 25198821,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3502.7613,
      "y": 2025
    },
    "life": {
      "v": 60.675,
      "y": 2024
    },
    "internet": {
      "v": 36.8015,
      "y": 2024
    },
    "co2": {
      "v": 0.3028,
      "y": 2024
    }
  },
  "478": {
    "id": "478",
    "iso3": "MRT",
    "name": "Mauritania",
    "nameFa": "موریتانی",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 5315065,
      "y": 2025
    },
    "gdpPpp": {
      "v": 7675.52,
      "y": 2025
    },
    "life": {
      "v": 68.713,
      "y": 2024
    },
    "internet": {
      "v": 45.7794,
      "y": 2024
    },
    "co2": {
      "v": 0.9695,
      "y": 2024
    }
  },
  "204": {
    "id": "204",
    "iso3": "BEN",
    "name": "Benin",
    "nameFa": "بنین",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 14814460,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4816.875,
      "y": 2025
    },
    "life": {
      "v": 60.961,
      "y": 2024
    },
    "internet": {
      "v": 33.9838,
      "y": 2024
    },
    "co2": {
      "v": 0.4873,
      "y": 2024
    }
  },
  "562": {
    "id": "562",
    "iso3": "NER",
    "name": "Niger",
    "nameFa": "نیجر",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 27917831,
      "y": 2025
    },
    "gdpPpp": {
      "v": 2177.2501,
      "y": 2025
    },
    "life": {
      "v": 61.433,
      "y": 2024
    },
    "internet": {
      "v": 15.5576,
      "y": 2024
    },
    "co2": {
      "v": 0.1189,
      "y": 2024
    }
  },
  "566": {
    "id": "566",
    "iso3": "NGA",
    "name": "Nigeria",
    "nameFa": "نیجریه",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 237527782,
      "y": 2025
    },
    "gdpPpp": {
      "v": 9531.6107,
      "y": 2025
    },
    "life": {
      "v": 54.635,
      "y": 2024
    },
    "internet": {
      "v": 41.2114,
      "y": 2024
    },
    "co2": {
      "v": 0.5669,
      "y": 2024
    }
  },
  "120": {
    "id": "120",
    "iso3": "CMR",
    "name": "Cameroon",
    "nameFa": "کامرون",
    "regionFa": "مرکز آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 29879337,
      "y": 2025
    },
    "gdpPpp": {
      "v": 5787.8544,
      "y": 2025
    },
    "life": {
      "v": 63.968,
      "y": 2024
    },
    "internet": {
      "v": 46.2588,
      "y": 2024
    },
    "co2": {
      "v": 0.3534,
      "y": 2024
    }
  },
  "768": {
    "id": "768",
    "iso3": "TGO",
    "name": "Togo",
    "nameFa": "توگو",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 8591626,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4079.3638,
      "y": 2025
    },
    "life": {
      "v": 62.935,
      "y": 2024
    },
    "internet": {
      "v": 39.4832,
      "y": 2024
    },
    "co2": {
      "v": 0.3126,
      "y": 2024
    }
  },
  "288": {
    "id": "288",
    "iso3": "GHA",
    "name": "Ghana",
    "nameFa": "غنا",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 35064272,
      "y": 2025
    },
    "gdpPpp": {
      "v": 8610.2797,
      "y": 2025
    },
    "life": {
      "v": 65.695,
      "y": 2024
    },
    "internet": {
      "v": 72.1757,
      "y": 2024
    },
    "co2": {
      "v": 0.7021,
      "y": 2024
    }
  },
  "384": {
    "id": "384",
    "iso3": "CIV",
    "name": "Côte d'Ivoire",
    "nameFa": "ساحل عاج",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 32711547,
      "y": 2025
    },
    "gdpPpp": {
      "v": 8208.909,
      "y": 2025
    },
    "life": {
      "v": 62.11,
      "y": 2024
    },
    "internet": {
      "v": 41.4322,
      "y": 2024
    },
    "co2": {
      "v": 0.5891,
      "y": 2024
    }
  },
  "324": {
    "id": "324",
    "iso3": "GIN",
    "name": "Guinea",
    "nameFa": "گینه",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 15099727,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4934.6513,
      "y": 2025
    },
    "life": {
      "v": 60.904,
      "y": 2024
    },
    "internet": {
      "v": 33.3047,
      "y": 2024
    },
    "co2": {
      "v": 0.3528,
      "y": 2024
    }
  },
  "624": {
    "id": "624",
    "iso3": "GNB",
    "name": "Guinea-Bissau",
    "nameFa": "گینه بیسائو",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 2249515,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3293.0953,
      "y": 2025
    },
    "life": {
      "v": 64.254,
      "y": 2024
    },
    "internet": {
      "v": 29.7774,
      "y": 2024
    },
    "co2": {
      "v": 0.1554,
      "y": 2024
    }
  },
  "430": {
    "id": "430",
    "iso3": "LBR",
    "name": "Liberia",
    "nameFa": "لیبریا",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 5731206,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1981.0948,
      "y": 2025
    },
    "life": {
      "v": 62.324,
      "y": 2024
    },
    "internet": {
      "v": 32.2336,
      "y": 2024
    },
    "co2": {
      "v": 0.1545,
      "y": 2024
    }
  },
  "694": {
    "id": "694",
    "iso3": "SLE",
    "name": "Sierra Leone",
    "nameFa": "سیرالئون",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 8819794,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3716.8941,
      "y": 2025
    },
    "life": {
      "v": 61.964,
      "y": 2024
    },
    "internet": {
      "v": 25.105,
      "y": 2024
    },
    "co2": {
      "v": 0.1692,
      "y": 2024
    }
  },
  "854": {
    "id": "854",
    "iso3": "BFA",
    "name": "Burkina Faso",
    "nameFa": "بورکینافاسو",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 24074580,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3071.6255,
      "y": 2025
    },
    "life": {
      "v": 61.292,
      "y": 2024
    },
    "internet": {
      "v": 28.2527,
      "y": 2024
    },
    "co2": {
      "v": 0.275,
      "y": 2024
    }
  },
  "140": {
    "id": "140",
    "iso3": "CAF",
    "name": "Central African Rep.",
    "nameFa": "جمهوری آفریقای مرکزی",
    "regionFa": "مرکز آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 5513282,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1313.8766,
      "y": 2025
    },
    "life": {
      "v": 57.671,
      "y": 2024
    },
    "internet": {
      "v": 13.7825,
      "y": 2024
    },
    "co2": {
      "v": 0.0633,
      "y": 2024
    }
  },
  "178": {
    "id": "178",
    "iso3": "COG",
    "name": "Congo",
    "nameFa": "کنگو",
    "regionFa": "مرکز آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 6484437,
      "y": 2025
    },
    "gdpPpp": {
      "v": 7248.4444,
      "y": 2025
    },
    "life": {
      "v": 66.001,
      "y": 2024
    },
    "internet": {
      "v": 47.2516,
      "y": 2024
    },
    "co2": {
      "v": 1.3354,
      "y": 2024
    }
  },
  "266": {
    "id": "266",
    "iso3": "GAB",
    "name": "Gabon",
    "nameFa": "گابن",
    "regionFa": "مرکز آفریقا",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 2593130,
      "y": 2025
    },
    "gdpPpp": {
      "v": 22218.3411,
      "y": 2025
    },
    "life": {
      "v": 68.511,
      "y": 2024
    },
    "internet": {
      "v": 68.7209,
      "y": 2024
    },
    "co2": {
      "v": 2.0475,
      "y": 2024
    }
  },
  "226": {
    "id": "226",
    "iso3": "GNQ",
    "name": "Eq. Guinea",
    "nameFa": "گینه استوایی",
    "regionFa": "مرکز آفریقا",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 1938431,
      "y": 2025
    },
    "gdpPpp": {
      "v": 16133.1056,
      "y": 2025
    },
    "life": {
      "v": 63.906,
      "y": 2024
    },
    "internet": {
      "v": 63.2993,
      "y": 2024
    },
    "co2": {
      "v": 2.5505,
      "y": 2024
    }
  },
  "894": {
    "id": "894",
    "iso3": "ZMB",
    "name": "Zambia",
    "nameFa": "زامبیا",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 21913874,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4379.2613,
      "y": 2025
    },
    "life": {
      "v": 66.528,
      "y": 2024
    },
    "internet": {
      "v": 17.101,
      "y": 2024
    },
    "co2": {
      "v": 0.543,
      "y": 2024
    }
  },
  "454": {
    "id": "454",
    "iso3": "MWI",
    "name": "Malawi",
    "nameFa": "مالاوی",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 22216120,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1899.2917,
      "y": 2025
    },
    "life": {
      "v": 67.561,
      "y": 2024
    },
    "internet": {
      "v": 18.9616,
      "y": 2024
    },
    "co2": {
      "v": 0.2214,
      "y": 2024
    }
  },
  "508": {
    "id": "508",
    "iso3": "MOZ",
    "name": "Mozambique",
    "nameFa": "موزامبیک",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 35631653,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1697.9411,
      "y": 2025
    },
    "life": {
      "v": 63.797,
      "y": 2024
    },
    "internet": {
      "v": 20.5273,
      "y": 2024
    },
    "co2": {
      "v": 0.292,
      "y": 2024
    }
  },
  "748": {
    "id": "748",
    "iso3": "SWZ",
    "name": "eSwatini",
    "nameFa": "اسواتینی",
    "regionFa": "جنوب آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 1256174,
      "y": 2025
    },
    "gdpPpp": {
      "v": 12529.2797,
      "y": 2025
    },
    "life": {
      "v": 64.264,
      "y": 2024
    },
    "internet": {
      "v": 63.4031,
      "y": 2024
    },
    "co2": {
      "v": 0.8803,
      "y": 2024
    }
  },
  "024": {
    "id": "024",
    "iso3": "AGO",
    "name": "Angola",
    "nameFa": "آنگولا",
    "regionFa": "مرکز آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 39040039,
      "y": 2025
    },
    "gdpPpp": {
      "v": 10251.3457,
      "y": 2025
    },
    "life": {
      "v": 64.805,
      "y": 2024
    },
    "internet": {
      "v": 40.7048,
      "y": 2024
    },
    "co2": {
      "v": 0.7417,
      "y": 2024
    }
  },
  "108": {
    "id": "108",
    "iso3": "BDI",
    "name": "Burundi",
    "nameFa": "بوروندی",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 14390003,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1248.0543,
      "y": 2025
    },
    "life": {
      "v": 63.818,
      "y": 2024
    },
    "internet": {
      "v": 8.596,
      "y": 2024
    },
    "co2": {
      "v": 0.069,
      "y": 2024
    }
  },
  "376": {
    "id": "376",
    "iso3": "ISR",
    "name": "Israel",
    "nameFa": "اسرائیل",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 10122800,
      "y": 2025
    },
    "gdpPpp": {
      "v": 59716.9735,
      "y": 2025
    },
    "life": {
      "v": 83.1976,
      "y": 2024
    },
    "internet": {
      "v": 88.1824,
      "y": 2024
    },
    "co2": {
      "v": 5.7653,
      "y": 2024
    }
  },
  "422": {
    "id": "422",
    "iso3": "LBN",
    "name": "Lebanon",
    "nameFa": "لبنان",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 5849421,
      "y": 2025
    },
    "gdpPpp": {
      "v": 11917.4503,
      "y": 2024
    },
    "life": {
      "v": 77.945,
      "y": 2024
    },
    "internet": {
      "v": 80.634,
      "y": 2024
    },
    "co2": {
      "v": 1.8953,
      "y": 2024
    }
  },
  "450": {
    "id": "450",
    "iso3": "MDG",
    "name": "Madagascar",
    "nameFa": "ماداگاسکار",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 32740678,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1952.4843,
      "y": 2025
    },
    "life": {
      "v": 63.835,
      "y": 2024
    },
    "internet": {
      "v": 18.6779,
      "y": 2024
    },
    "co2": {
      "v": 0.1465,
      "y": 2024
    }
  },
  "275": {
    "id": "275",
    "iso3": "PSE",
    "name": "Palestine",
    "nameFa": "فلسطین",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 5413596,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4999.713,
      "y": 2025
    },
    "life": {
      "v": 69.213,
      "y": 2024
    },
    "internet": {
      "v": 86.6377,
      "y": 2023
    },
    "co2": null
  },
  "270": {
    "id": "270",
    "iso3": "GMB",
    "name": "Gambia",
    "nameFa": "گامبیا",
    "regionFa": "غرب آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 2822093,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3705.6418,
      "y": 2025
    },
    "life": {
      "v": 66.057,
      "y": 2024
    },
    "internet": {
      "v": 49.4943,
      "y": 2024
    },
    "co2": {
      "v": 0.1784,
      "y": 2024
    }
  },
  "788": {
    "id": "788",
    "iso3": "TUN",
    "name": "Tunisia",
    "nameFa": "تونس",
    "regionFa": "شمال آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 12348573,
      "y": 2025
    },
    "gdpPpp": {
      "v": 15233.4886,
      "y": 2025
    },
    "life": {
      "v": 76.711,
      "y": 2024
    },
    "internet": {
      "v": 76.5,
      "y": 2024
    },
    "co2": {
      "v": 2.6211,
      "y": 2024
    }
  },
  "012": {
    "id": "012",
    "iso3": "DZA",
    "name": "Algeria",
    "nameFa": "الجزایر",
    "regionFa": "شمال آفریقا",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 47435312,
      "y": 2025
    },
    "gdpPpp": {
      "v": 18586.2607,
      "y": 2025
    },
    "life": {
      "v": 76.475,
      "y": 2024
    },
    "internet": {
      "v": 77.4178,
      "y": 2024
    },
    "co2": {
      "v": 3.9808,
      "y": 2024
    }
  },
  "400": {
    "id": "400",
    "iso3": "JOR",
    "name": "Jordan",
    "nameFa": "اردن",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 11520684,
      "y": 2025
    },
    "gdpPpp": {
      "v": 12631.6299,
      "y": 2025
    },
    "life": {
      "v": 77.981,
      "y": 2024
    },
    "internet": {
      "v": 95.6224,
      "y": 2024
    },
    "co2": {
      "v": 2.0899,
      "y": 2024
    }
  },
  "784": {
    "id": "784",
    "iso3": "ARE",
    "name": "United Arab Emirates",
    "nameFa": "امارات متحده عربی",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 11513149,
      "y": 2025
    },
    "gdpPpp": {
      "v": 79343.7793,
      "y": 2024
    },
    "life": {
      "v": 83.069,
      "y": 2024
    },
    "internet": {
      "v": 100.0,
      "y": 2024
    },
    "co2": {
      "v": 18.2552,
      "y": 2024
    }
  },
  "634": {
    "id": "634",
    "iso3": "QAT",
    "name": "Qatar",
    "nameFa": "قطر",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 2972215,
      "y": 2025
    },
    "gdpPpp": {
      "v": 128882.9342,
      "y": 2025
    },
    "life": {
      "v": 82.522,
      "y": 2024
    },
    "internet": {
      "v": 98.0854,
      "y": 2024
    },
    "co2": {
      "v": 47.3322,
      "y": 2024
    }
  },
  "414": {
    "id": "414",
    "iso3": "KWT",
    "name": "Kuwait",
    "nameFa": "کویت",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 4865298,
      "y": 2025
    },
    "gdpPpp": {
      "v": 56467.7272,
      "y": 2025
    },
    "life": {
      "v": 84.5805,
      "y": 2024
    },
    "internet": {
      "v": 100.0,
      "y": 2025
    },
    "co2": {
      "v": 23.6727,
      "y": 2024
    }
  },
  "368": {
    "id": "368",
    "iso3": "IRQ",
    "name": "Iraq",
    "nameFa": "عراق",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 47020774,
      "y": 2025
    },
    "gdpPpp": {
      "v": 14266.7965,
      "y": 2025
    },
    "life": {
      "v": 72.424,
      "y": 2024
    },
    "internet": {
      "v": 81.4745,
      "y": 2024
    },
    "co2": {
      "v": 5.1838,
      "y": 2024
    }
  },
  "512": {
    "id": "512",
    "iso3": "OMN",
    "name": "Oman",
    "nameFa": "عمان",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 5494691,
      "y": 2025
    },
    "gdpPpp": {
      "v": 42295.1761,
      "y": 2025
    },
    "life": {
      "v": 80.246,
      "y": 2024
    },
    "internet": {
      "v": 95.2517,
      "y": 2024
    },
    "co2": {
      "v": 18.652,
      "y": 2024
    }
  },
  "548": {
    "id": "548",
    "iso3": "VUT",
    "name": "Vanuatu",
    "nameFa": "وانواتو",
    "regionFa": "ملانزی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 335169,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4525.2365,
      "y": 2025
    },
    "life": {
      "v": 71.654,
      "y": 2024
    },
    "internet": {
      "v": 22.3514,
      "y": 2015
    },
    "co2": {
      "v": 0.8698,
      "y": 2024
    }
  },
  "116": {
    "id": "116",
    "iso3": "KHM",
    "name": "Cambodia",
    "nameFa": "کامبوج",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 17847982,
      "y": 2025
    },
    "gdpPpp": {
      "v": 8542.6965,
      "y": 2025
    },
    "life": {
      "v": 70.817,
      "y": 2024
    },
    "internet": {
      "v": 68.4753,
      "y": 2024
    },
    "co2": {
      "v": 1.1021,
      "y": 2024
    }
  },
  "764": {
    "id": "764",
    "iso3": "THA",
    "name": "Thailand",
    "nameFa": "تایلند",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 71619863,
      "y": 2025
    },
    "gdpPpp": {
      "v": 26250.0724,
      "y": 2025
    },
    "life": {
      "v": 76.564,
      "y": 2024
    },
    "internet": {
      "v": 90.8672,
      "y": 2024
    },
    "co2": {
      "v": 3.9601,
      "y": 2024
    }
  },
  "418": {
    "id": "418",
    "iso3": "LAO",
    "name": "Laos",
    "nameFa": "لائوس",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 7873046,
      "y": 2025
    },
    "gdpPpp": {
      "v": 10382.9991,
      "y": 2025
    },
    "life": {
      "v": 69.225,
      "y": 2024
    },
    "internet": {
      "v": 65.5927,
      "y": 2024
    },
    "co2": {
      "v": 3.3544,
      "y": 2024
    }
  },
  "104": {
    "id": "104",
    "iso3": "MMR",
    "name": "Myanmar",
    "nameFa": "میانمار",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 54850648,
      "y": 2025
    },
    "gdpPpp": {
      "v": 6011.5349,
      "y": 2025
    },
    "life": {
      "v": 67.095,
      "y": 2024
    },
    "internet": {
      "v": 45.4477,
      "y": 2020
    },
    "co2": {
      "v": 0.5755,
      "y": 2024
    }
  },
  "704": {
    "id": "704",
    "iso3": "VNM",
    "name": "Vietnam",
    "nameFa": "ویتنام",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 101598527,
      "y": 2025
    },
    "gdpPpp": {
      "v": 18088.4916,
      "y": 2025
    },
    "life": {
      "v": 74.736,
      "y": 2024
    },
    "internet": {
      "v": 84.15,
      "y": 2024
    },
    "co2": {
      "v": 4.2661,
      "y": 2024
    }
  },
  "408": {
    "id": "408",
    "iso3": "PRK",
    "name": "North Korea",
    "nameFa": "کره شمالی",
    "regionFa": "آسیای شرقی",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 26571036,
      "y": 2025
    },
    "gdpPpp": null,
    "life": {
      "v": 73.743,
      "y": 2024
    },
    "internet": {
      "v": 0.0,
      "y": 2004
    },
    "co2": {
      "v": 2.4997,
      "y": 2024
    }
  },
  "410": {
    "id": "410",
    "iso3": "KOR",
    "name": "South Korea",
    "nameFa": "کره جنوبی",
    "regionFa": "آسیای شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 51684564,
      "y": 2025
    },
    "gdpPpp": {
      "v": 63124.9152,
      "y": 2025
    },
    "life": {
      "v": 83.6293,
      "y": 2024
    },
    "internet": {
      "v": 97.8956,
      "y": 2024
    },
    "co2": {
      "v": 11.3623,
      "y": 2024
    }
  },
  "496": {
    "id": "496",
    "iso3": "MNG",
    "name": "Mongolia",
    "nameFa": "مغولستان",
    "regionFa": "آسیای شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 3568978,
      "y": 2025
    },
    "gdpPpp": {
      "v": 20797.7653,
      "y": 2025
    },
    "life": {
      "v": 72.398,
      "y": 2024
    },
    "internet": {
      "v": 85.1235,
      "y": 2024
    },
    "co2": {
      "v": 7.8467,
      "y": 2024
    }
  },
  "356": {
    "id": "356",
    "iso3": "IND",
    "name": "India",
    "nameFa": "هند",
    "regionFa": "آسیای جنوبی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 1463865525,
      "y": 2025
    },
    "gdpPpp": {
      "v": 11747.916,
      "y": 2025
    },
    "life": {
      "v": 72.235,
      "y": 2024
    },
    "internet": {
      "v": 70.0,
      "y": 2025
    },
    "co2": {
      "v": 2.1737,
      "y": 2024
    }
  },
  "050": {
    "id": "050",
    "iso3": "BGD",
    "name": "Bangladesh",
    "nameFa": "بنگلادش",
    "regionFa": "آسیای جنوبی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 175686899,
      "y": 2025
    },
    "gdpPpp": {
      "v": 10153.7084,
      "y": 2025
    },
    "life": {
      "v": 74.93,
      "y": 2024
    },
    "internet": {
      "v": 53.4217,
      "y": 2024
    },
    "co2": {
      "v": 0.7155,
      "y": 2024
    }
  },
  "064": {
    "id": "064",
    "iso3": "BTN",
    "name": "Bhutan",
    "nameFa": "بوتان",
    "regionFa": "آسیای جنوبی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 796682,
      "y": 2025
    },
    "gdpPpp": {
      "v": 19594.0028,
      "y": 2025
    },
    "life": {
      "v": 73.262,
      "y": 2024
    },
    "internet": {
      "v": 91.2774,
      "y": 2024
    },
    "co2": {
      "v": 2.0112,
      "y": 2024
    }
  },
  "524": {
    "id": "524",
    "iso3": "NPL",
    "name": "Nepal",
    "nameFa": "نپال",
    "regionFa": "آسیای جنوبی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 29618118,
      "y": 2025
    },
    "gdpPpp": {
      "v": 6175.159,
      "y": 2025
    },
    "life": {
      "v": 70.636,
      "y": 2024
    },
    "internet": {
      "v": 46.3219,
      "y": 2024
    },
    "co2": {
      "v": 0.536,
      "y": 2024
    }
  },
  "586": {
    "id": "586",
    "iso3": "PAK",
    "name": "Pakistan",
    "nameFa": "پاکستان",
    "regionFa": "آسیای جنوبی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 255219554,
      "y": 2025
    },
    "gdpPpp": {
      "v": 6573.4161,
      "y": 2025
    },
    "life": {
      "v": 67.799,
      "y": 2024
    },
    "internet": {
      "v": 57.253,
      "y": 2024
    },
    "co2": {
      "v": 0.8118,
      "y": 2024
    }
  },
  "004": {
    "id": "004",
    "iso3": "AFG",
    "name": "Afghanistan",
    "nameFa": "افغانستان",
    "regionFa": "آسیای جنوبی",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 43844111,
      "y": 2025
    },
    "gdpPpp": {
      "v": 2236.1991,
      "y": 2024
    },
    "life": {
      "v": 66.289,
      "y": 2024
    },
    "internet": {
      "v": 16.095,
      "y": 2024
    },
    "co2": {
      "v": 0.283,
      "y": 2024
    }
  },
  "762": {
    "id": "762",
    "iso3": "TJK",
    "name": "Tajikistan",
    "nameFa": "تاجیکستان",
    "regionFa": "آسیای مرکزی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 10786734,
      "y": 2025
    },
    "gdpPpp": {
      "v": 5923.4718,
      "y": 2025
    },
    "life": {
      "v": 71.927,
      "y": 2024
    },
    "internet": {
      "v": 55.7934,
      "y": 2024
    },
    "co2": {
      "v": 0.9225,
      "y": 2024
    }
  },
  "417": {
    "id": "417",
    "iso3": "KGZ",
    "name": "Kyrgyzstan",
    "nameFa": "قرقیزستان",
    "regionFa": "آسیای مرکزی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 7343064,
      "y": 2025
    },
    "gdpPpp": {
      "v": 9219.5144,
      "y": 2025
    },
    "life": {
      "v": 72.4,
      "y": 2024
    },
    "internet": {
      "v": 92.0286,
      "y": 2024
    },
    "co2": {
      "v": 1.4878,
      "y": 2024
    }
  },
  "795": {
    "id": "795",
    "iso3": "TKM",
    "name": "Turkmenistan",
    "nameFa": "ترکمنستان",
    "regionFa": "آسیای مرکزی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 7618847,
      "y": 2025
    },
    "gdpPpp": {
      "v": 22601.5518,
      "y": 2025
    },
    "life": {
      "v": 70.201,
      "y": 2024
    },
    "internet": {
      "v": 17.9903,
      "y": 2016
    },
    "co2": {
      "v": 10.8624,
      "y": 2024
    }
  },
  "364": {
    "id": "364",
    "iso3": "IRN",
    "name": "Iran",
    "nameFa": "ایران",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 92417681,
      "y": 2025
    },
    "gdpPpp": {
      "v": 19699.2194,
      "y": 2025
    },
    "life": {
      "v": 77.854,
      "y": 2024
    },
    "internet": {
      "v": 85.3404,
      "y": 2024
    },
    "co2": {
      "v": 9.0533,
      "y": 2024
    }
  },
  "760": {
    "id": "760",
    "iso3": "SYR",
    "name": "Syria",
    "nameFa": "سوریه",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 25620427,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4905.1525,
      "y": 2022
    },
    "life": {
      "v": 72.56,
      "y": 2024
    },
    "internet": {
      "v": 33.77,
      "y": 2018
    },
    "co2": {
      "v": 1.2747,
      "y": 2024
    }
  },
  "051": {
    "id": "051",
    "iso3": "ARM",
    "name": "Armenia",
    "nameFa": "ارمنستان",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 3086700,
      "y": 2025
    },
    "gdpPpp": {
      "v": 24754.2118,
      "y": 2025
    },
    "life": {
      "v": 78.3195,
      "y": 2024
    },
    "internet": {
      "v": 81.3393,
      "y": 2024
    },
    "co2": {
      "v": 2.4703,
      "y": 2024
    }
  },
  "752": {
    "id": "752",
    "iso3": "SWE",
    "name": "Sweden",
    "nameFa": "سوئد",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 10596620,
      "y": 2025
    },
    "gdpPpp": {
      "v": 72528.8893,
      "y": 2025
    },
    "life": {
      "v": 84.0634,
      "y": 2024
    },
    "internet": {
      "v": 95.7663,
      "y": 2025
    },
    "co2": {
      "v": 3.5738,
      "y": 2024
    }
  },
  "112": {
    "id": "112",
    "iso3": "BLR",
    "name": "Belarus",
    "nameFa": "بلاروس",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 9085991,
      "y": 2025
    },
    "gdpPpp": {
      "v": 34715.9779,
      "y": 2025
    },
    "life": {
      "v": 74.3653,
      "y": 2024
    },
    "internet": {
      "v": 94.2618,
      "y": 2024
    },
    "co2": {
      "v": 5.9365,
      "y": 2024
    }
  },
  "804": {
    "id": "804",
    "iso3": "UKR",
    "name": "Ukraine",
    "nameFa": "اوکراین",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 38980376,
      "y": 2025
    },
    "gdpPpp": {
      "v": 18904.9805,
      "y": 2025
    },
    "life": {
      "v": 74.692,
      "y": 2024
    },
    "internet": {
      "v": 82.4749,
      "y": 2024
    },
    "co2": {
      "v": 3.1293,
      "y": 2024
    }
  },
  "616": {
    "id": "616",
    "iso3": "POL",
    "name": "Poland",
    "nameFa": "لهستان",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 36435861,
      "y": 2025
    },
    "gdpPpp": {
      "v": 54262.404,
      "y": 2025
    },
    "life": {
      "v": 78.4098,
      "y": 2024
    },
    "internet": {
      "v": 88.585,
      "y": 2024
    },
    "co2": {
      "v": 7.5511,
      "y": 2024
    }
  },
  "040": {
    "id": "040",
    "iso3": "AUT",
    "name": "Austria",
    "nameFa": "اتریش",
    "regionFa": "اروپای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 9208163,
      "y": 2025
    },
    "gdpPpp": {
      "v": 76777.5422,
      "y": 2025
    },
    "life": {
      "v": 81.9951,
      "y": 2024
    },
    "internet": {
      "v": 91.9257,
      "y": 2025
    },
    "co2": {
      "v": 6.3228,
      "y": 2024
    }
  },
  "348": {
    "id": "348",
    "iso3": "HUN",
    "name": "Hungary",
    "nameFa": "مجارستان",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 9514251,
      "y": 2025
    },
    "gdpPpp": {
      "v": 49837.6008,
      "y": 2025
    },
    "life": {
      "v": 76.7244,
      "y": 2024
    },
    "internet": {
      "v": 93.779,
      "y": 2024
    },
    "co2": {
      "v": 4.4579,
      "y": 2024
    }
  },
  "498": {
    "id": "498",
    "iso3": "MDA",
    "name": "Moldova",
    "nameFa": "مولداوی",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 2360527,
      "y": 2025
    },
    "gdpPpp": {
      "v": 19995.7591,
      "y": 2025
    },
    "life": {
      "v": 71.332,
      "y": 2024
    },
    "internet": {
      "v": 77.3688,
      "y": 2024
    },
    "co2": {
      "v": 3.4168,
      "y": 2024
    }
  },
  "642": {
    "id": "642",
    "iso3": "ROU",
    "name": "Romania",
    "nameFa": "رومانی",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 19020271,
      "y": 2025
    },
    "gdpPpp": {
      "v": 50895.0816,
      "y": 2025
    },
    "life": {
      "v": 76.4585,
      "y": 2024
    },
    "internet": {
      "v": 91.2905,
      "y": 2024
    },
    "co2": {
      "v": 3.7206,
      "y": 2024
    }
  },
  "440": {
    "id": "440",
    "iso3": "LTU",
    "name": "Lithuania",
    "nameFa": "لیتوانی",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 2888774,
      "y": 2025
    },
    "gdpPpp": {
      "v": 56837.8067,
      "y": 2025
    },
    "life": {
      "v": 77.1951,
      "y": 2024
    },
    "internet": {
      "v": 89.1612,
      "y": 2024
    },
    "co2": {
      "v": 4.4906,
      "y": 2024
    }
  },
  "428": {
    "id": "428",
    "iso3": "LVA",
    "name": "Latvia",
    "nameFa": "لتونی",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 1847785,
      "y": 2025
    },
    "gdpPpp": {
      "v": 46136.6894,
      "y": 2025
    },
    "life": {
      "v": 76.4293,
      "y": 2024
    },
    "internet": {
      "v": 92.7076,
      "y": 2024
    },
    "co2": {
      "v": 3.6478,
      "y": 2024
    }
  },
  "233": {
    "id": "233",
    "iso3": "EST",
    "name": "Estonia",
    "nameFa": "استونی",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 1366475,
      "y": 2025
    },
    "gdpPpp": {
      "v": 52105.5093,
      "y": 2025
    },
    "life": {
      "v": 79.2951,
      "y": 2024
    },
    "internet": {
      "v": 92.238,
      "y": 2024
    },
    "co2": {
      "v": 7.7594,
      "y": 2024
    }
  },
  "276": {
    "id": "276",
    "iso3": "DEU",
    "name": "Germany",
    "nameFa": "آلمان",
    "regionFa": "اروپای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 83491249,
      "y": 2025
    },
    "gdpPpp": {
      "v": 75406.6888,
      "y": 2025
    },
    "life": {
      "v": 80.7927,
      "y": 2024
    },
    "internet": {
      "v": 93.5,
      "y": 2024
    },
    "co2": {
      "v": 6.944,
      "y": 2024
    }
  },
  "100": {
    "id": "100",
    "iso3": "BGR",
    "name": "Bulgaria",
    "nameFa": "بلغارستان",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 6433302,
      "y": 2025
    },
    "gdpPpp": {
      "v": 44451.1002,
      "y": 2025
    },
    "life": {
      "v": 75.761,
      "y": 2024
    },
    "internet": {
      "v": 82.439,
      "y": 2024
    },
    "co2": {
      "v": 5.3076,
      "y": 2024
    }
  },
  "300": {
    "id": "300",
    "iso3": "GRC",
    "name": "Greece",
    "nameFa": "یونان",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 10413962,
      "y": 2025
    },
    "gdpPpp": {
      "v": 45263.6499,
      "y": 2025
    },
    "life": {
      "v": 81.839,
      "y": 2024
    },
    "internet": {
      "v": 86.2697,
      "y": 2024
    },
    "co2": {
      "v": 5.0464,
      "y": 2024
    }
  },
  "792": {
    "id": "792",
    "iso3": "TUR",
    "name": "Turkey",
    "nameFa": "ترکیه",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 85878556,
      "y": 2025
    },
    "gdpPpp": {
      "v": 45288.475,
      "y": 2025
    },
    "life": {
      "v": 77.421,
      "y": 2024
    },
    "internet": {
      "v": 89.7702,
      "y": 2025
    },
    "co2": {
      "v": 5.3793,
      "y": 2024
    }
  },
  "008": {
    "id": "008",
    "iso3": "ALB",
    "name": "Albania",
    "nameFa": "آلبانی",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 2349580,
      "y": 2025
    },
    "gdpPpp": {
      "v": 28220.7951,
      "y": 2025
    },
    "life": {
      "v": 79.776,
      "y": 2024
    },
    "internet": {
      "v": 85.8639,
      "y": 2024
    },
    "co2": {
      "v": 1.7852,
      "y": 2024
    }
  },
  "191": {
    "id": "191",
    "iso3": "HRV",
    "name": "Croatia",
    "nameFa": "کرواسی",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 3876200,
      "y": 2025
    },
    "gdpPpp": {
      "v": 50946.1671,
      "y": 2025
    },
    "life": {
      "v": 78.9293,
      "y": 2024
    },
    "internet": {
      "v": 83.6324,
      "y": 2024
    },
    "co2": {
      "v": 4.8315,
      "y": 2024
    }
  },
  "756": {
    "id": "756",
    "iso3": "CHE",
    "name": "Switzerland",
    "nameFa": "سوئیس",
    "regionFa": "اروپای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 9092436,
      "y": 2025
    },
    "gdpPpp": {
      "v": 102513.3472,
      "y": 2025
    },
    "life": {
      "v": 84.4073,
      "y": 2024
    },
    "internet": {
      "v": 97.321,
      "y": 2025
    },
    "co2": {
      "v": 3.7457,
      "y": 2024
    }
  },
  "442": {
    "id": "442",
    "iso3": "LUX",
    "name": "Luxembourg",
    "nameFa": "لوکزامبورگ",
    "regionFa": "اروپای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 686970,
      "y": 2025
    },
    "gdpPpp": {
      "v": 156542.0758,
      "y": 2025
    },
    "life": {
      "v": 83.1951,
      "y": 2024
    },
    "internet": {
      "v": 99.129,
      "y": 2025
    },
    "co2": {
      "v": 10.5573,
      "y": 2024
    }
  },
  "056": {
    "id": "056",
    "iso3": "BEL",
    "name": "Belgium",
    "nameFa": "بلژیک",
    "regionFa": "اروپای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 11941781,
      "y": 2025
    },
    "gdpPpp": {
      "v": 74675.6077,
      "y": 2025
    },
    "life": {
      "v": 82.3,
      "y": 2024
    },
    "internet": {
      "v": 95.7758,
      "y": 2024
    },
    "co2": {
      "v": 7.3066,
      "y": 2024
    }
  },
  "528": {
    "id": "528",
    "iso3": "NLD",
    "name": "Netherlands",
    "nameFa": "هلند",
    "regionFa": "اروپای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 18087633,
      "y": 2025
    },
    "gdpPpp": {
      "v": 87320.1477,
      "y": 2025
    },
    "life": {
      "v": 81.9659,
      "y": 2024
    },
    "internet": {
      "v": 97.0068,
      "y": 2024
    },
    "co2": {
      "v": 6.6019,
      "y": 2024
    }
  },
  "620": {
    "id": "620",
    "iso3": "PRT",
    "name": "Portugal",
    "nameFa": "پرتغال",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 10804871,
      "y": 2025
    },
    "gdpPpp": {
      "v": 53145.7317,
      "y": 2025
    },
    "life": {
      "v": 82.3829,
      "y": 2024
    },
    "internet": {
      "v": 88.487,
      "y": 2024
    },
    "co2": {
      "v": 3.3248,
      "y": 2024
    }
  },
  "724": {
    "id": "724",
    "iso3": "ESP",
    "name": "Spain",
    "nameFa": "اسپانیا",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 49355143,
      "y": 2025
    },
    "gdpPpp": {
      "v": 59867.6945,
      "y": 2025
    },
    "life": {
      "v": 83.8878,
      "y": 2024
    },
    "internet": {
      "v": 95.7575,
      "y": 2024
    },
    "co2": {
      "v": 4.5054,
      "y": 2024
    }
  },
  "372": {
    "id": "372",
    "iso3": "IRL",
    "name": "Ireland",
    "nameFa": "ایرلند",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 5484367,
      "y": 2025
    },
    "gdpPpp": {
      "v": 155089.4131,
      "y": 2025
    },
    "life": {
      "v": 83.0098,
      "y": 2024
    },
    "internet": {
      "v": 97.1877,
      "y": 2024
    },
    "co2": {
      "v": 6.0361,
      "y": 2024
    }
  },
  "540": {
    "id": "540",
    "iso3": "NCL",
    "name": "New Caledonia",
    "nameFa": "کالدونیای جدید",
    "regionFa": "ملانزی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 295333,
      "y": 2025
    },
    "gdpPpp": null,
    "life": {
      "v": 78.921,
      "y": 2024
    },
    "internet": {
      "v": 82.0058,
      "y": 2017
    },
    "co2": {
      "v": 17.0801,
      "y": 2024
    }
  },
  "090": {
    "id": "090",
    "iso3": "SLB",
    "name": "Solomon Is.",
    "nameFa": "جزایر سلیمان",
    "regionFa": "ملانزی",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 838645,
      "y": 2025
    },
    "gdpPpp": {
      "v": 2787.6166,
      "y": 2025
    },
    "life": {
      "v": 70.694,
      "y": 2024
    },
    "internet": {
      "v": 29.0407,
      "y": 2024
    },
    "co2": {
      "v": 0.3839,
      "y": 2024
    }
  },
  "554": {
    "id": "554",
    "iso3": "NZL",
    "name": "New Zealand",
    "nameFa": "نیوزیلند",
    "regionFa": "استرالیا و نیوزیلند",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 5324700,
      "y": 2025
    },
    "gdpPpp": {
      "v": 57350.3628,
      "y": 2025
    },
    "life": {
      "v": 82.0098,
      "y": 2024
    },
    "internet": {
      "v": 93.5193,
      "y": 2024
    },
    "co2": {
      "v": 6.0141,
      "y": 2024
    }
  },
  "036": {
    "id": "036",
    "iso3": "AUS",
    "name": "Australia",
    "nameFa": "استرالیا",
    "regionFa": "استرالیا و نیوزیلند",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 27614411,
      "y": 2025
    },
    "gdpPpp": {
      "v": 71934.4034,
      "y": 2025
    },
    "life": {
      "v": 83.0512,
      "y": 2024
    },
    "internet": {
      "v": 96.1314,
      "y": 2024
    },
    "co2": {
      "v": 14.0987,
      "y": 2024
    }
  },
  "144": {
    "id": "144",
    "iso3": "LKA",
    "name": "Sri Lanka",
    "nameFa": "سری‌لانکا",
    "regionFa": "آسیای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 21756000,
      "y": 2025
    },
    "gdpPpp": {
      "v": 17065.0299,
      "y": 2025
    },
    "life": {
      "v": 77.672,
      "y": 2024
    },
    "internet": {
      "v": 54.59,
      "y": 2024
    },
    "co2": {
      "v": 1.0647,
      "y": 2024
    }
  },
  "156": {
    "id": "156",
    "iso3": "CHN",
    "name": "China",
    "nameFa": "چین",
    "regionFa": "آسیای شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 1406585000,
      "y": 2025
    },
    "gdpPpp": {
      "v": 29333.3311,
      "y": 2025
    },
    "life": {
      "v": 78.017,
      "y": 2024
    },
    "internet": {
      "v": 91.6,
      "y": 2025
    },
    "co2": {
      "v": 9.3151,
      "y": 2024
    }
  },
  "158": {
    "id": "158",
    "iso3": "TWN",
    "name": "Taiwan",
    "nameFa": "تایوان",
    "regionFa": "آسیای شرقی",
    "incomeFa": null,
    "population": null,
    "gdpPpp": null,
    "life": null,
    "internet": null,
    "co2": null
  },
  "380": {
    "id": "380",
    "iso3": "ITA",
    "name": "Italy",
    "nameFa": "ایتالیا",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 58915656,
      "y": 2025
    },
    "gdpPpp": {
      "v": 62802.5108,
      "y": 2025
    },
    "life": {
      "v": 83.9512,
      "y": 2024
    },
    "internet": {
      "v": 89.2207,
      "y": 2024
    },
    "co2": {
      "v": 5.0757,
      "y": 2024
    }
  },
  "208": {
    "id": "208",
    "iso3": "DNK",
    "name": "Denmark",
    "nameFa": "دانمارک",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 6009169,
      "y": 2025
    },
    "gdpPpp": {
      "v": 83218.0715,
      "y": 2025
    },
    "life": {
      "v": 82.2537,
      "y": 2024
    },
    "internet": {
      "v": 99.7692,
      "y": 2024
    },
    "co2": {
      "v": 4.2782,
      "y": 2024
    }
  },
  "826": {
    "id": "826",
    "iso3": "GBR",
    "name": "United Kingdom",
    "nameFa": "بریتانیا",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 69487000,
      "y": 2025
    },
    "gdpPpp": {
      "v": 64606.4955,
      "y": 2025
    },
    "life": {
      "v": 81.3869,
      "y": 2024
    },
    "internet": {
      "v": 95.4721,
      "y": 2024
    },
    "co2": {
      "v": 4.2208,
      "y": 2024
    }
  },
  "352": {
    "id": "352",
    "iso3": "ISL",
    "name": "Iceland",
    "nameFa": "ایسلند",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 392404,
      "y": 2025
    },
    "gdpPpp": {
      "v": 83431.2131,
      "y": 2025
    },
    "life": {
      "v": 82.8098,
      "y": 2024
    },
    "internet": {
      "v": 98.2092,
      "y": 2024
    },
    "co2": {
      "v": 8.5199,
      "y": 2024
    }
  },
  "031": {
    "id": "031",
    "iso3": "AZE",
    "name": "Azerbaijan",
    "nameFa": "آذربایجان",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 10246996,
      "y": 2025
    },
    "gdpPpp": {
      "v": 26112.5307,
      "y": 2025
    },
    "life": {
      "v": 74.576,
      "y": 2024
    },
    "internet": {
      "v": 90.8,
      "y": 2025
    },
    "co2": {
      "v": 3.8114,
      "y": 2024
    }
  },
  "268": {
    "id": "268",
    "iso3": "GEO",
    "name": "Georgia",
    "nameFa": "گرجستان",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 3935766,
      "y": 2025
    },
    "gdpPpp": {
      "v": 29414.3813,
      "y": 2025
    },
    "life": {
      "v": 74.657,
      "y": 2024
    },
    "internet": {
      "v": 83.7986,
      "y": 2024
    },
    "co2": {
      "v": 3.5324,
      "y": 2024
    }
  },
  "608": {
    "id": "608",
    "iso3": "PHL",
    "name": "Philippines",
    "nameFa": "فیلیپین",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 116786962,
      "y": 2025
    },
    "gdpPpp": {
      "v": 12576.9867,
      "y": 2025
    },
    "life": {
      "v": 69.946,
      "y": 2024
    },
    "internet": {
      "v": 67.263,
      "y": 2024
    },
    "co2": {
      "v": 1.503,
      "y": 2024
    }
  },
  "458": {
    "id": "458",
    "iso3": "MYS",
    "name": "Malaysia",
    "nameFa": "مالزی",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 35977838,
      "y": 2025
    },
    "gdpPpp": {
      "v": 41497.6746,
      "y": 2025
    },
    "life": {
      "v": 76.821,
      "y": 2024
    },
    "internet": {
      "v": 98.0206,
      "y": 2024
    },
    "co2": {
      "v": 8.3232,
      "y": 2024
    }
  },
  "096": {
    "id": "096",
    "iso3": "BRN",
    "name": "Brunei",
    "nameFa": "برونئی",
    "regionFa": "آسیای جنوب شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 466330,
      "y": 2025
    },
    "gdpPpp": {
      "v": 92429.9263,
      "y": 2025
    },
    "life": {
      "v": 75.501,
      "y": 2024
    },
    "internet": {
      "v": 96.2983,
      "y": 2024
    },
    "co2": {
      "v": 20.2427,
      "y": 2024
    }
  },
  "705": {
    "id": "705",
    "iso3": "SVN",
    "name": "Slovenia",
    "nameFa": "اسلوونی",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 2130986,
      "y": 2025
    },
    "gdpPpp": {
      "v": 59244.7106,
      "y": 2025
    },
    "life": {
      "v": 82.2854,
      "y": 2024
    },
    "internet": {
      "v": 90.7636,
      "y": 2024
    },
    "co2": {
      "v": 6.2665,
      "y": 2024
    }
  },
  "246": {
    "id": "246",
    "iso3": "FIN",
    "name": "Finland",
    "nameFa": "فنلاند",
    "regionFa": "اروپای شمالی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 5646436,
      "y": 2025
    },
    "gdpPpp": {
      "v": 65884.4877,
      "y": 2025
    },
    "life": {
      "v": 82.3366,
      "y": 2024
    },
    "internet": {
      "v": 93.7241,
      "y": 2024
    },
    "co2": {
      "v": 5.5352,
      "y": 2024
    }
  },
  "703": {
    "id": "703",
    "iso3": "SVK",
    "name": "Slovakia",
    "nameFa": "اسلواکی",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 5413813,
      "y": 2025
    },
    "gdpPpp": {
      "v": 49308.7048,
      "y": 2025
    },
    "life": {
      "v": 78.3707,
      "y": 2024
    },
    "internet": {
      "v": 89.8251,
      "y": 2024
    },
    "co2": {
      "v": 5.5131,
      "y": 2024
    }
  },
  "203": {
    "id": "203",
    "iso3": "CZE",
    "name": "Czechia",
    "nameFa": "چک",
    "regionFa": "اروپای شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 10886878,
      "y": 2025
    },
    "gdpPpp": {
      "v": 60487.2877,
      "y": 2025
    },
    "life": {
      "v": 79.978,
      "y": 2024
    },
    "internet": {
      "v": 87.6878,
      "y": 2024
    },
    "co2": {
      "v": 7.1297,
      "y": 2024
    }
  },
  "232": {
    "id": "232",
    "iso3": "ERI",
    "name": "Eritrea",
    "nameFa": "اریتره",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 3607003,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1742.3236,
      "y": 2011
    },
    "life": {
      "v": 68.893,
      "y": 2024
    },
    "internet": {
      "v": 14.3494,
      "y": 2020
    },
    "co2": {
      "v": 0.22,
      "y": 2024
    }
  },
  "392": {
    "id": "392",
    "iso3": "JPN",
    "name": "Japan",
    "nameFa": "ژاپن",
    "regionFa": "آسیای شرقی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 123366734,
      "y": 2025
    },
    "gdpPpp": {
      "v": 55421.8798,
      "y": 2025
    },
    "life": {
      "v": 84.0363,
      "y": 2024
    },
    "internet": {
      "v": 85.5415,
      "y": 2024
    },
    "co2": {
      "v": 7.8424,
      "y": 2024
    }
  },
  "600": {
    "id": "600",
    "iso3": "PRY",
    "name": "Paraguay",
    "nameFa": "پاراگوئه",
    "regionFa": "آمریکای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 7013078,
      "y": 2025
    },
    "gdpPpp": {
      "v": 20181.4243,
      "y": 2025
    },
    "life": {
      "v": 73.982,
      "y": 2024
    },
    "internet": {
      "v": 81.5781,
      "y": 2024
    },
    "co2": {
      "v": 1.1582,
      "y": 2024
    }
  },
  "887": {
    "id": "887",
    "iso3": "YEM",
    "name": "Yemen",
    "nameFa": "یمن",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 41773878,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3164.3215,
      "y": 2013
    },
    "life": {
      "v": 69.439,
      "y": 2024
    },
    "internet": {
      "v": 17.491,
      "y": 2019
    },
    "co2": {
      "v": 0.2607,
      "y": 2024
    }
  },
  "682": {
    "id": "682",
    "iso3": "SAU",
    "name": "Saudi Arabia",
    "nameFa": "عربستان سعودی",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 36973555,
      "y": 2025
    },
    "gdpPpp": {
      "v": 73783.5614,
      "y": 2025
    },
    "life": {
      "v": 78.982,
      "y": 2024
    },
    "internet": {
      "v": 100.0,
      "y": 2024
    },
    "co2": {
      "v": 18.4846,
      "y": 2024
    }
  },
  "010": {
    "id": "010",
    "iso3": "ATA",
    "name": "Antarctica",
    "nameFa": "جنوبگان",
    "regionFa": "جنوبگان",
    "incomeFa": null,
    "population": null,
    "gdpPpp": null,
    "life": null,
    "internet": null,
    "co2": null
  },
  "name:N. Cyprus": {
    "id": "name:N. Cyprus",
    "iso3": null,
    "name": "N. Cyprus",
    "nameFa": "N. Cyprus",
    "regionFa": "—",
    "incomeFa": null,
    "population": null,
    "gdpPpp": null,
    "life": null,
    "internet": null,
    "co2": null
  },
  "196": {
    "id": "196",
    "iso3": "CYP",
    "name": "Cyprus",
    "nameFa": "قبرس",
    "regionFa": "آسیای غربی",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 1370754,
      "y": 2025
    },
    "gdpPpp": {
      "v": 64574.6211,
      "y": 2025
    },
    "life": {
      "v": 81.821,
      "y": 2024
    },
    "internet": {
      "v": 89.601,
      "y": 2024
    },
    "co2": {
      "v": 5.4047,
      "y": 2024
    }
  },
  "504": {
    "id": "504",
    "iso3": "MAR",
    "name": "Morocco",
    "nameFa": "مراکش",
    "regionFa": "شمال آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 38430770,
      "y": 2025
    },
    "gdpPpp": {
      "v": 11111.708,
      "y": 2025
    },
    "life": {
      "v": 75.493,
      "y": 2024
    },
    "internet": {
      "v": 91.2,
      "y": 2024
    },
    "co2": {
      "v": 1.8393,
      "y": 2024
    }
  },
  "818": {
    "id": "818",
    "iso3": "EGY",
    "name": "Egypt",
    "nameFa": "مصر",
    "regionFa": "شمال آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 118365995,
      "y": 2025
    },
    "gdpPpp": {
      "v": 20204.0131,
      "y": 2025
    },
    "life": {
      "v": 71.806,
      "y": 2024
    },
    "internet": {
      "v": 74.6484,
      "y": 2024
    },
    "co2": {
      "v": 2.5025,
      "y": 2024
    }
  },
  "434": {
    "id": "434",
    "iso3": "LBY",
    "name": "Libya",
    "nameFa": "لیبی",
    "regionFa": "شمال آفریقا",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 7458555,
      "y": 2025
    },
    "gdpPpp": {
      "v": 16521.3998,
      "y": 2025
    },
    "life": {
      "v": 71.121,
      "y": 2024
    },
    "internet": {
      "v": 81.9545,
      "y": 2024
    },
    "co2": {
      "v": 8.6646,
      "y": 2024
    }
  },
  "231": {
    "id": "231",
    "iso3": "ETH",
    "name": "Ethiopia",
    "nameFa": "اتیوپی",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 135472051,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3621.6749,
      "y": 2025
    },
    "life": {
      "v": 67.603,
      "y": 2024
    },
    "internet": {
      "v": 21.9413,
      "y": 2024
    },
    "co2": {
      "v": 0.1466,
      "y": 2024
    }
  },
  "262": {
    "id": "262",
    "iso3": "DJI",
    "name": "Djibouti",
    "nameFa": "جیبوتی",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد متوسط رو به پایین",
    "population": {
      "v": 1184076,
      "y": 2025
    },
    "gdpPpp": {
      "v": 8451.9684,
      "y": 2025
    },
    "life": {
      "v": 66.202,
      "y": 2024
    },
    "internet": {
      "v": 65.2989,
      "y": 2024
    },
    "co2": {
      "v": 0.7655,
      "y": 2024
    }
  },
  "name:Somaliland": {
    "id": "name:Somaliland",
    "iso3": null,
    "name": "Somaliland",
    "nameFa": "Somaliland",
    "regionFa": "—",
    "incomeFa": null,
    "population": null,
    "gdpPpp": null,
    "life": null,
    "internet": null,
    "co2": null
  },
  "800": {
    "id": "800",
    "iso3": "UGA",
    "name": "Uganda",
    "nameFa": "اوگاندا",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 51384894,
      "y": 2025
    },
    "gdpPpp": {
      "v": 3487.698,
      "y": 2025
    },
    "life": {
      "v": 68.487,
      "y": 2024
    },
    "internet": {
      "v": 8.9498,
      "y": 2024
    },
    "co2": {
      "v": 0.165,
      "y": 2024
    }
  },
  "646": {
    "id": "646",
    "iso3": "RWA",
    "name": "Rwanda",
    "nameFa": "رواندا",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 14569341,
      "y": 2025
    },
    "gdpPpp": {
      "v": 4164.4366,
      "y": 2025
    },
    "life": {
      "v": 68.017,
      "y": 2024
    },
    "internet": {
      "v": 31.7033,
      "y": 2024
    },
    "co2": {
      "v": 0.1621,
      "y": 2024
    }
  },
  "070": {
    "id": "070",
    "iso3": "BIH",
    "name": "Bosnia and Herz.",
    "nameFa": "بوسنی و هرزگوین",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 3140095,
      "y": 2025
    },
    "gdpPpp": {
      "v": 25814.2642,
      "y": 2025
    },
    "life": {
      "v": 78.044,
      "y": 2024
    },
    "internet": {
      "v": 86.1009,
      "y": 2024
    },
    "co2": {
      "v": 6.4494,
      "y": 2024
    }
  },
  "807": {
    "id": "807",
    "iso3": "MKD",
    "name": "Macedonia",
    "nameFa": "مقدونیه شمالی",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 1820909,
      "y": 2025
    },
    "gdpPpp": {
      "v": 28028.5664,
      "y": 2025
    },
    "life": {
      "v": 76.6166,
      "y": 2024
    },
    "internet": {
      "v": 93.1,
      "y": 2025
    },
    "co2": {
      "v": 3.9999,
      "y": 2024
    }
  },
  "688": {
    "id": "688",
    "iso3": "SRB",
    "name": "Serbia",
    "nameFa": "صربستان",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 6549143,
      "y": 2025
    },
    "gdpPpp": {
      "v": 33909.7606,
      "y": 2025
    },
    "life": {
      "v": 75.9683,
      "y": 2024
    },
    "internet": {
      "v": 87.6907,
      "y": 2024
    },
    "co2": null
  },
  "499": {
    "id": "499",
    "iso3": "MNE",
    "name": "Montenegro",
    "nameFa": "مونته‌نگرو",
    "regionFa": "اروپای جنوبی",
    "incomeFa": "درآمد متوسط رو به بالا",
    "population": {
      "v": 623129,
      "y": 2025
    },
    "gdpPpp": {
      "v": 35422.645,
      "y": 2025
    },
    "life": {
      "v": 77.8902,
      "y": 2024
    },
    "internet": {
      "v": 88.8826,
      "y": 2024
    },
    "co2": null
  },
  "name:Kosovo": {
    "id": "name:Kosovo",
    "iso3": null,
    "name": "Kosovo",
    "nameFa": "Kosovo",
    "regionFa": "—",
    "incomeFa": null,
    "population": null,
    "gdpPpp": null,
    "life": null,
    "internet": null,
    "co2": null
  },
  "780": {
    "id": "780",
    "iso3": "TTO",
    "name": "Trinidad and Tobago",
    "nameFa": "ترینیداد و توباگو",
    "regionFa": "کارائیب",
    "incomeFa": "درآمد بالا",
    "population": {
      "v": 1367764,
      "y": 2025
    },
    "gdpPpp": {
      "v": 37121.205,
      "y": 2025
    },
    "life": {
      "v": 73.617,
      "y": 2024
    },
    "internet": {
      "v": 82.1599,
      "y": 2024
    },
    "co2": {
      "v": 19.5811,
      "y": 2024
    }
  },
  "728": {
    "id": "728",
    "iso3": "SSD",
    "name": "S. Sudan",
    "nameFa": "سودان جنوبی",
    "regionFa": "شرق آفریقا",
    "incomeFa": "درآمد پایین",
    "population": {
      "v": 12188788,
      "y": 2025
    },
    "gdpPpp": {
      "v": 1154.8869,
      "y": 2015
    },
    "life": {
      "v": 57.738,
      "y": 2024
    },
    "internet": {
      "v": 6.671,
      "y": 2019
    },
    "co2": null
  }
}
