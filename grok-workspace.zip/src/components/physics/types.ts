export type BodyKind = "sphere" | "box" | "cylinder"

export type BodySpec = {
  id: number
  kind: BodyKind
  position: [number, number, number]
  rotation: [number, number, number]
  size: number
}

export const BODY_CAP = 36
