import { useCallback, useMemo, useState } from "react"
import { Search } from "lucide-react"
import { COUNTRIES, type CountryDatum } from "@/data/countries"
import {
  METRIC_ORDER,
  METRICS,
  formatInt,
  formatRank,
  formatYear,
  getMetricModel,
  normalizeQuery,
  type MetricKey,
  type MetricModel,
} from "@/lib/metrics"
import { WorldMap, type MapTip } from "@/components/atlas/world-map"

const LIST = Object.values(COUNTRIES)

export function AtlasView() {
  const [metric, setMetric] = useState<MetricKey>("population")
  const [hoverId, setHoverId] = useState<string | null>(null)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [query, setQuery] = useState("")
  const [frame, setFrame] = useState<{ id: string; n: number }>({ id: "", n: 0 })
  const model = useMemo(() => getMetricModel(metric), [metric])
  const fills = useMemo(() => {
    const next: Record<string, string> = {}
    for (const country of LIST) next[country.id] = model.colorOf(country.id)
    return next
  }, [model])

  const onHover = useCallback((id: string | null) => setHoverId(id), [])
  const onSelect = useCallback((id: string) => setSelectedId(id), [])

  const hover = hoverId ? COUNTRIES[hoverId] : undefined
  const hoverRow = hoverId ? model.byId[hoverId] : undefined
  const tip: MapTip | null = hover
    ? {
        title: hover.nameFa,
        sub: hover.name,
        value: hoverRow ? model.def.format(hoverRow.value) : "بدون داده",
        extra: hoverRow
          ? `${formatRank(model.rank[hover.id], model.total)} · ${formatYear(hoverRow.year)}`
          : model.def.label,
      }
    : null

  const selected = selectedId ? COUNTRIES[selectedId] : undefined
  const q = normalizeQuery(query)
  const results = q
    ? LIST.filter((country) => {
        const hay = normalizeQuery(`${country.nameFa} ${country.name} ${country.regionFa}`)
        return hay.includes(q)
      }).slice(0, 12)
    : []

  return (
    <div className="flex h-full min-h-0 flex-col md:flex-row">
      <section className="flex min-h-0 basis-3/5 flex-col bg-paper text-ink md:min-w-0 md:flex-1 md:basis-auto">
        <div className="flex shrink-0 gap-2 overflow-x-auto px-3 py-3 scroll-clean">
          {METRIC_ORDER.map((key) => {
            const active = key === metric
            return (
              <button
                key={key}
                type="button"
                aria-pressed={active}
                onClick={() => setMetric(key)}
                className={
                  "h-11 shrink-0 rounded-full px-4 text-sm font-medium " +
                  (active ? "bg-ink text-paper" : "border border-sand bg-paper text-ink")
                }
              >
                {METRICS[key].label}
              </button>
            )
          })}
        </div>
        <WorldMap
          fills={fills}
          hoverId={hoverId}
          selectedId={selectedId}
          tip={tip}
          frameNonce={frame.n}
          frameId={frame.id || null}
          onHover={onHover}
          onSelect={onSelect}
        />
        <Legend modelMin={model.min} modelMax={model.max} modelMid={model.mid} label={model.def.label} logarithmic={model.def.scale === "log"} format={model.def.format} />
      </section>
      <aside className="flex min-h-0 basis-2/5 flex-col border-t border-line bg-ink md:w-80 md:shrink-0 md:basis-auto md:border-t-0 md:border-s">
        <div className="shrink-0 border-b border-line p-3">
          <label className="relative block">
            <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="جستجوی کشور"
              className="h-11 w-full rounded-md border border-line bg-ink-2 ps-10 pe-3 text-sm text-fg outline-none placeholder:text-muted"
            />
          </label>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-3">
          {q ? (
            <ResultList
              countries={results}
              model={model}
              onPick={(id) => {
                setSelectedId(id)
                setFrame({ id, n: Date.now() })
                setQuery("")
              }}
            />
          ) : selected ? (
            <CountryDetail
              country={selected}
              model={model}
              onBack={() => setSelectedId(null)}
            />
          ) : (
            <Ranking model={model} onPick={(id) => {
              setSelectedId(id)
              setFrame({ id, n: Date.now() })
            }} />
          )}
        </div>
      </aside>
    </div>
  )
}

function Legend({
  label,
  logarithmic,
  modelMin,
  modelMid,
  modelMax,
  format,
}: {
  label: string
  logarithmic: boolean
  modelMin: number
  modelMid: number
  modelMax: number
  format: (n: number) => string
}) {
  return (
    <div className="shrink-0 border-t border-sand px-4 py-3">
      <div className="mx-auto w-full max-w-md">
        <p className="mb-2 text-xs font-medium">
          {label}
          {logarithmic ? " · مقیاس لگاریتمی" : ""}
        </p>
        <div className="legend-bar" />
        <div className="mt-1 flex justify-between text-xs text-deep">
          <span>{format(modelMax)}</span>
          <span>{format(modelMid)}</span>
          <span>{format(modelMin)}</span>
        </div>
        <p className="mt-1 text-xs text-deep">بدون داده با خاکستری روشن. بانک جهانی، تازه‌ترین سال هر کشور.</p>
      </div>
    </div>
  )
}

function Ranking({
  model,
  onPick,
}: {
  model: MetricModel
  onPick: (id: string) => void
}) {
  return (
    <div>
      <p className="text-xs text-muted">معیار</p>
      <h2 className="mt-1 text-xl font-semibold">{model.def.label}</h2>
      <p className="mt-1 text-sm text-muted">{model.def.hint}</p>
      <p className="mt-4 text-xs font-medium text-muted">بالاترین‌ها</p>
      <ul className="mt-1">
        {model.rows.slice(0, 8).map((row) => {
          const country = COUNTRIES[row.id]
          return (
            <li key={row.id}>
              <button
                type="button"
                onClick={() => onPick(row.id)}
                className="flex h-11 w-full items-center gap-3 rounded-md px-1 text-start hover:bg-panel"
              >
                <span className="w-6 text-xs text-muted">{formatInt(model.rank[row.id])}</span>
                <span className="size-2.5 shrink-0 rounded-full" style={{ background: model.colorOf(row.id) }} />
                <span className="min-w-0 flex-1 truncate text-sm">{country?.nameFa ?? row.id}</span>
                <span className="text-sm font-medium">{model.def.format(row.value)}</span>
              </button>
            </li>
          )
        })}
      </ul>
      <p className="mt-4 text-xs leading-relaxed text-muted">
        کشور را روی نقشه بزنید یا از فهرست انتخاب کنید. میانهٔ جهان {model.def.format(model.median)} است.
      </p>
    </div>
  )
}

function ResultList({
  countries,
  model,
  onPick,
}: {
  countries: CountryDatum[]
  model: MetricModel
  onPick: (id: string) => void
}) {
  if (countries.length === 0) {
    return <p className="px-1 py-6 text-sm text-muted">کشوری با این نام پیدا نشد.</p>
  }
  return (
    <ul>
      {countries.map((country) => {
        const row = model.byId[country.id]
        return (
          <li key={country.id}>
            <button
              type="button"
              onClick={() => onPick(country.id)}
              className="flex h-12 w-full items-center gap-3 rounded-md px-1 text-start hover:bg-panel"
            >
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm">{country.nameFa}</span>
                <span className="block truncate text-xs text-muted">{country.name}</span>
              </span>
              <span className="text-sm">{row ? model.def.format(row.value) : "—"}</span>
            </button>
          </li>
        )
      })}
    </ul>
  )
}

function CountryDetail({
  country,
  model,
  onBack,
}: {
  country: CountryDatum
  model: MetricModel
  onBack: () => void
}) {
  const row = model.byId[country.id]
  return (
    <div>
      <button type="button" onClick={onBack} className="text-sm text-accent">
        رتبه‌بندی
      </button>
      <div className="mt-3 flex items-start gap-3">
        <span
          className="mt-1 size-4 shrink-0 rounded-full border border-line"
          style={{ background: model.colorOf(country.id) }}
        />
        <div className="min-w-0">
          <h2 className="text-2xl font-semibold leading-tight">{country.nameFa}</h2>
          <p className="text-sm text-muted">
            {country.name} · {country.regionFa}
          </p>
          {country.incomeFa ? <p className="text-sm text-muted">{country.incomeFa}</p> : null}
        </div>
      </div>
      <p className="mt-5 text-xs text-muted">{model.def.label}</p>
      <p className="text-3xl font-semibold text-accent">{row ? model.def.format(row.value) : "بدون داده"}</p>
      <p className="mt-1 text-sm text-muted">
        {row ? `${formatRank(model.rank[country.id], model.total)} · ${formatYear(row.year)}` : "برای این معیار داده‌ای ثبت نشده"}
      </p>
      {row ? (
        <p className="mt-2 text-sm">
          میانهٔ جهان {model.def.format(model.median)}
          {row.value >= model.median ? " · بالاتر از میانه" : " · پایین‌تر از میانه"}
        </p>
      ) : null}
      <ul className="mt-6 space-y-3">
        {METRIC_ORDER.map((key) => {
          const def = METRICS[key]
          const stat = country[key]
          const local = stat ? Math.min(1, Math.max(0, getMetricModel(key).tOf(stat.v))) : 0
          const active = key === model.key
          return (
            <li key={key}>
              <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
                <span className={active ? "font-semibold" : "text-muted"}>{def.label}</span>
                <span>{stat ? def.format(stat.v) : "—"}</span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-line">
                <div
                  className={"h-full origin-right rounded-full " + (active ? "bg-accent" : "bg-sage")}
                  style={{ transform: `scaleX(${local})` }}
                />
              </div>
            </li>
          )
        })}
      </ul>
      <p className="mt-6 text-xs leading-relaxed text-muted">
        منبع: بانک جهانی. اعداد برای نمایش‌اند و سال هر شاخص کنار مقدار آمده است. خاکستری نقشه یعنی داده نیست.
      </p>
    </div>
  )
}
