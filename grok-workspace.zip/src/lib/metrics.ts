import { COUNTRIES, type CountryDatum, type Stat } from "@/data/countries"
import { palette } from "@/lib/palette"

export type MetricKey = "population" | "gdpPpp" | "life" | "internet" | "co2"

export const METRIC_ORDER: MetricKey[] = ["population", "gdpPpp", "life", "internet", "co2"]

const nf = new Intl.NumberFormat("fa-IR")
const nf1 = new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 1 })
const nfYear = new Intl.NumberFormat("fa-IR", { useGrouping: false })

export function formatYear(year: number) {
  return nfYear.format(year)
}

export function formatInt(n: number) {
  return nfYear.format(n)
}

export function formatPopulation(n: number) {
  const abs = Math.abs(n)
  if (abs >= 1e9) return `${nf1.format(n / 1e9)} میلیارد`
  if (abs >= 1e6) return `${nf1.format(n / 1e6)} میلیون`
  if (abs >= 1e3) return `${nf1.format(n / 1e3)} هزار`
  return nf.format(Math.round(n))
}

export function formatMoney(n: number) {
  return `${nf.format(Math.round(n))} دلار`
}

export function formatYears(n: number) {
  return `${nf1.format(n)} سال`
}

export function formatPercent(n: number) {
  return `${nf1.format(n)}٪`
}

export function formatTons(n: number) {
  return `${nf1.format(n)} تن`
}

export function formatRank(rank: number, total: number) {
  return `رتبه ${nf.format(rank)} از ${nf.format(total)}`
}

type MetricDef = {
  key: MetricKey
  label: string
  hint: string
  scale: "log" | "linear"
  format: (n: number) => string
}

export const METRICS: Record<MetricKey, MetricDef> = {
  population: {
    key: "population",
    label: "جمعیت",
    hint: "کل جمعیت",
    scale: "log",
    format: formatPopulation,
  },
  gdpPpp: {
    key: "gdpPpp",
    label: "تولید سرانه",
    hint: "تولید ناخالص داخلی سرانه، برابری قدرت خرید",
    scale: "log",
    format: formatMoney,
  },
  life: {
    key: "life",
    label: "امید به زندگی",
    hint: "امید به زندگی در بدو تولد",
    scale: "linear",
    format: formatYears,
  },
  internet: {
    key: "internet",
    label: "اینترنت",
    hint: "سهم افرادی که از اینترنت استفاده می‌کنند",
    scale: "linear",
    format: formatPercent,
  },
  co2: {
    key: "co2",
    label: "کربن سرانه",
    hint: "انتشار دی‌اکسید کربن به ازای هر نفر",
    scale: "log",
    format: formatTons,
  },
}

export type MetricRow = { id: string; value: number; year: number }

export type MetricModel = {
  key: MetricKey
  def: MetricDef
  rows: MetricRow[]
  byId: Record<string, MetricRow>
  rank: Record<string, number>
  min: number
  max: number
  mid: number
  median: number
  total: number
  colorOf: (id: string) => string
  tOf: (value: number) => number
}

function hexChannels(hex: string): [number, number, number] {
  const n = hex.replace("#", "")
  return [parseInt(n.slice(0, 2), 16), parseInt(n.slice(2, 4), 16), parseInt(n.slice(4, 6), 16)]
}

function mix(a: string, b: string, t: number) {
  const pa = hexChannels(a)
  const pb = hexChannels(b)
  const c = pa.map((v, i) => Math.round(v + (pb[i] - v) * t))
  return `rgb(${c[0]} ${c[1]} ${c[2]})`
}

export function colorAt(t: number) {
  const x = Math.min(1, Math.max(0, t))
  if (x < 0.5) return mix(palette.scale0, palette.scale1, x * 2)
  return mix(palette.scale1, palette.scale2, (x - 0.5) * 2)
}

export function valueToT(value: number, min: number, max: number, scale: "log" | "linear") {
  if (!(max > min)) return 0.5
  if (scale === "log") {
    const lo = Math.log(Math.max(min, 1e-6))
    const hi = Math.log(Math.max(max, 1e-6))
    if (hi === lo) return 0.5
    return (Math.log(Math.max(value, 1e-6)) - lo) / (hi - lo)
  }
  return (value - min) / (max - min)
}

function medianOf(values: number[]) {
  if (values.length === 0) return 0
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid]
}

export function statOf(country: CountryDatum, key: MetricKey): Stat | null {
  return country[key]
}

const modelCache = new Map<MetricKey, MetricModel>()

export function getMetricModel(key: MetricKey) {
  let model = modelCache.get(key)
  if (!model) {
    model = buildMetricModel(key)
    modelCache.set(key, model)
  }
  return model
}

export function buildMetricModel(key: MetricKey): MetricModel {
  const def = METRICS[key]
  const rows: MetricRow[] = []
  for (const country of Object.values(COUNTRIES)) {
    const stat = statOf(country, key)
    if (!stat) continue
    if (def.scale === "log" && !(stat.v > 0)) continue
    rows.push({ id: country.id, value: stat.v, year: stat.y })
  }
  rows.sort((a, b) => b.value - a.value || a.id.localeCompare(b.id))
  const values = rows.map((row) => row.value)
  const min = values.length ? values[values.length - 1] : 0
  const max = values.length ? values[0] : 1
  const mid =
    def.scale === "log"
      ? Math.exp((Math.log(Math.max(min, 1e-6)) + Math.log(Math.max(max, 1e-6))) / 2)
      : (min + max) / 2
  const byId: Record<string, MetricRow> = {}
  const rank: Record<string, number> = {}
  for (let i = 0; i < rows.length; i++) {
    byId[rows[i].id] = rows[i]
    rank[rows[i].id] = i + 1
  }
  const tOf = (value: number) => valueToT(value, min, max, def.scale)
  return {
    key,
    def,
    rows,
    byId,
    rank,
    min,
    max,
    mid,
    median: medianOf(values),
    total: rows.length,
    tOf,
    colorOf: (id: string) => {
      const row = byId[id]
      return row ? colorAt(tOf(row.value)) : palette.nodata
    },
  }
}

export function normalizeQuery(value: string) {
  return value
    .toLowerCase()
    .replace(/ي/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/\s+/g, " ")
    .trim()
}
